/**
 * Deploy this separately with the Firebase CLI:
 *   firebase deploy --only functions
 *
 * This is NOT part of the Flutter/FlutLab build — Cloud Functions run on
 * Google's servers, not inside the app. It's what makes payments trustworthy:
 * the client only ever talks to createOrder / razorpayWebhook; it can never
 * write isPremium, premiumUntil or coinBalance itself.
 *
 * Also contains `truecallerSignIn`, which turns a Truecaller login into a
 * Firebase custom token (see the "TRUECALLER SIGN-IN" section below). It needs
 * Node 18+ (uses the built-in fetch) and needs NO extra config: the Truecaller
 * Client ID is public, and the PKCE flow means no client secret is used.
 *
 * Setup:
 *   1. npm install firebase-admin firebase-functions razorpay
 *   2. Set your Razorpay KEY SECRET (never in the Flutter app!) as a
 *      Firebase secret:
 *        firebase functions:secrets:set RAZORPAY_KEY_SECRET
 *   3. In the Razorpay dashboard, add a webhook pointing to your deployed
 *      razorpayWebhook URL, subscribed to the "payment.captured" event, and
 *      set the same secret there for signature verification.
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const crypto = require("crypto");
const Razorpay = require("razorpay");

admin.initializeApp();
const db = admin.firestore();

// Created on first use (not at load time), so a missing Razorpay config only
// affects the payment functions and can't stop the other functions from loading.
let _razorpay;
function getRazorpay() {
  if (!_razorpay) {
    _razorpay = new Razorpay({
      key_id: functions.config().razorpay.key_id,
      key_secret: functions.config().razorpay.key_secret,
    });
  }
  return _razorpay;
}

// Client calls this to start a purchase (subscription or coins).
exports.createOrder = functions.https.onRequest(async (req, res) => {
  const { uid, amount, currency, purpose, coins } = req.body;

  if (!uid || !amount || !currency) {
    return res.status(400).json({ error: "Missing uid, amount, or currency" });
  }

  const order = await getRazorpay().orders.create({
    amount, // in paise
    currency,
    notes: { uid, purpose: purpose || "premium", coins: coins || 0 },
  });

  res.json({ orderId: order.id });
});

// Razorpay calls this automatically after a successful payment.
// This is the ONLY place that ever grants premium status or coins.
exports.razorpayWebhook = functions.https.onRequest(async (req, res) => {
  const signature = req.headers["x-razorpay-signature"];
  const expected = crypto
    .createHmac("sha256", functions.config().razorpay.webhook_secret)
    .update(JSON.stringify(req.body))
    .digest("hex");

  if (signature !== expected) {
    return res.status(400).send("Invalid signature");
  }

  const payload = req.body.payload.payment.entity;
  const notes = payload.notes || {};
  const uid = notes.uid;
  if (!uid) return res.status(400).send("Missing uid in order notes");

  const userRef = db.collection("users").doc(uid);

  if (notes.purpose === "coins") {
    await userRef.set(
      { coinBalance: admin.firestore.FieldValue.increment(Number(notes.coins) || 0) },
      { merge: true }
    );
  } else {
    // Default: premium subscription, +30 days from now.
    const premiumUntil = admin.firestore.Timestamp.fromDate(
      new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    );
    await userRef.set({ isPremium: true, premiumUntil }, { merge: true });
  }

  res.status(200).send("OK");
});


// =====================================================================
// TRUECALLER SIGN-IN
// =====================================================================
// The app gets an authorization code from the Truecaller SDK and sends it
// here together with its PKCE code verifier. We:
//   1. exchange them with Truecaller for an access token,
//   2. read the verified profile (name / phone),
//   3. create-or-find the Firebase Auth user for that Truecaller account,
//   4. make sure the users/{uid} document exists as a "main_user",
//   5. return a Firebase custom token the app signs in with.
//
// The Truecaller Client ID is public (it is also in AndroidManifest.xml).
// If your Truecaller project is in the EU region, deploy with
//   TRUECALLER_OAUTH_BASE=https://oauth-account-eu.truecaller.com
const TRUECALLER_CLIENT_ID =
  process.env.TRUECALLER_CLIENT_ID ||
  "zfnc12kqyyn3a8sqp9hjyfdixj0rxiojbtsyebackb0";
const TRUECALLER_OAUTH_BASE =
  process.env.TRUECALLER_OAUTH_BASE ||
  "https://oauth-account-noneu.truecaller.com";

exports.truecallerSignIn = functions.https.onCall(async (data) => {
  const code = data && data.authorizationCode;
  const verifier = data && data.codeVerifier;
  if (typeof code !== "string" || !code || typeof verifier !== "string" || !verifier) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "authorizationCode and codeVerifier are required."
    );
  }

  // 1. code (+ PKCE verifier) -> access token
  const tokenRes = await fetch(`${TRUECALLER_OAUTH_BASE}/v1/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      client_id: TRUECALLER_CLIENT_ID,
      code,
      code_verifier: verifier,
    }).toString(),
  });
  if (!tokenRes.ok) {
    console.error("Truecaller token exchange failed", tokenRes.status);
    throw new functions.https.HttpsError(
      "unauthenticated",
      "Truecaller could not verify this login."
    );
  }
  const tokenJson = await tokenRes.json();
  if (!tokenJson.access_token) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "Truecaller did not return an access token."
    );
  }

  // 2. access token -> verified profile
  const infoRes = await fetch(`${TRUECALLER_OAUTH_BASE}/v1/userinfo`, {
    headers: { Authorization: `Bearer ${tokenJson.access_token}` },
  });
  if (!infoRes.ok) {
    console.error("Truecaller userinfo failed", infoRes.status);
    throw new functions.https.HttpsError(
      "unauthenticated",
      "Could not read your Truecaller profile."
    );
  }
  const profile = await infoRes.json();
  if (!profile.sub) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "Truecaller profile had no user id."
    );
  }

  // 3. stable Firebase uid for this Truecaller account
  const uid = ("tc_" + String(profile.sub).replace(/[^A-Za-z0-9_-]/g, "")).slice(0, 128);
  const displayName =
    [profile.given_name, profile.family_name].filter(Boolean).join(" ") ||
    profile.name ||
    "Truecaller User";
  const photoURL =
    typeof profile.picture === "string" && profile.picture.startsWith("http")
      ? profile.picture
      : undefined;

  try {
    await admin.auth().getUser(uid);
  } catch (e) {
    if (e.code !== "auth/user-not-found") throw e;
    await admin.auth().createUser({ uid, displayName, photoURL });
  }

  // 4. Firestore profile: every new account is a Main User
  const userRef = db.collection("users").doc(uid);
  const snap = await userRef.get();
  if (!snap.exists) {
    await userRef.set({
      displayName,
      email: "",
      photoUrl: photoURL || "",
      userType: "main_user",
      authProvider: "truecaller",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  } else if (!snap.data().userType) {
    await userRef.set({ userType: "main_user" }, { merge: true });
  }

  // Phone number goes in a PRIVATE doc: users/{uid} is publicly readable.
  if (profile.phone_number) {
    await userRef.collection("private").doc("contact").set(
      {
        phoneNumber: String(profile.phone_number),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  }

  // 5. Firebase custom token for the app
  const customToken = await admin.auth().createCustomToken(uid, { provider: "truecaller" });
  return { customToken };
});
