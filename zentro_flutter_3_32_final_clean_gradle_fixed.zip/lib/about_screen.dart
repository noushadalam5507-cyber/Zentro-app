import 'package:flutter/material.dart';

/// Settings -> About. Shows the app and who founded it.
class AboutScreen extends StatelessWidget {
  const AboutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07020D),
      appBar: AppBar(title: const Text('About')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 84,
                height: 84,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFFFF6B00),
                      Color(0xFFFF1493),
                      Color(0xFFA855F7),
                      Color(0xFF00D2FF),
                    ],
                  ),
                ),
                child:
                    const Icon(Icons.flash_on, color: Colors.white, size: 48),
              ),
            ),
            const SizedBox(height: 16),
            const Center(
              child: Text(
                'ZENTRO 4K STUDIO',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                ),
              ),
            ),
            const SizedBox(height: 6),
            const Center(
              child: Text('Version 1.0.0',
                  style: TextStyle(color: Colors.white54)),
            ),
            const SizedBox(height: 28),

            // ---- Founder ----
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFFF1493), width: 1),
              ),
              child: Row(
                children: const [
                  CircleAvatar(
                    radius: 26,
                    backgroundColor: Color(0xFFFF1493),
                    child: Icon(Icons.verified, color: Colors.white),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('FOUNDER',
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 12,
                              letterSpacing: 2,
                              fontWeight: FontWeight.bold,
                            )),
                        SizedBox(height: 4),
                        Text('Noushad Alam',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            )),
                        Text('नौशाद आलम',
                            style: TextStyle(
                                color: Colors.white70, fontSize: 15)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Zentro is a social app for sharing reels and stories, '
              'chatting, and video calling with friends.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }
}
