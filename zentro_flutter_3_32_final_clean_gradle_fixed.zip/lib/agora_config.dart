// ============================================================
// AGORA CONFIGURATION
// ============================================================
// Get your App ID from: https://console.agora.io
// -> Project Management -> your project -> copy "App ID"
//
// PASTE YOUR AGORA APP ID ON THE LINE BELOW (line 10),
// inside the quotes, replacing the placeholder text.
// ============================================================

class AgoraConfig {
  static const String appId = "868473cb9fb846718fc575f433699315"; // <-- line 10

  // Optional: if you enable "App Certificate" (token authentication) in the
  // Agora console for production security, generate a temporary token from
  // the Agora console (Project -> Config -> generate temp token) and paste
  // it here. Leave empty ("") only while App Certificate is DISABLED
  // (fine for testing, not recommended for production).
  static const String tempToken = "";

  // Any string both users agree on to join the same call/room.
  static const String defaultChannelName = "zentro_main_channel";
}
