import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'openrouter_service.dart';
import 'voice_service.dart';

class _Msg {
  final bool fromUser;
  final String text;
  final File? image;
  final bool isError;
  const _Msg({
    required this.fromUser,
    required this.text,
    this.image,
    this.isError = false,
  });
}

/// Full AI chat: typed text, photo analysis, voice input, spoken replies.
class AiChatScreen extends StatefulWidget {
  const AiChatScreen({Key? key}) : super(key: key);

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> with SingleTickerProviderStateMixin {
  static const Color _accent = Color(0xFFFF1493);

  final OpenRouterService _ai = OpenRouterService();
  final VoiceService _voice = VoiceService();
  final ImagePicker _picker = ImagePicker();
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final List<_Msg> _msgs = <_Msg>[];
  late final AnimationController _logoController;

  File? _pendingImage;
  bool _sending = false;
  bool _listening = false;
  bool _speakReplies = true;

  @override
  void initState() {
    super.initState();
    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();
    _voice.onListeningStopped = () {
      if (mounted && _listening) setState(() => _listening = false);
    };
    _voice.onError = (String message) {
      if (mounted) _toast(message);
    };
  }

  @override
  void dispose() {
    _logoController.dispose();
    _voice.dispose();
    _ai.dispose();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _toast(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  // ------------------------------------------------------------- sending

  Future<void> _send() async {
    final String text = _input.text.trim();
    final File? image = _pendingImage;
    if ((text.isEmpty && image == null) || _sending) return;

    await _voice.stopSpeaking();
    await _voice.stopListening();

    setState(() {
      _msgs.add(_Msg(fromUser: true, text: text, image: image));
      _sending = true;
      _listening = false;
      _pendingImage = null;
      _input.clear();
    });
    _scrollToEnd();

    try {
      final String reply = image != null
          ? await _ai.sendImage(image, prompt: text)
          : await _ai.sendText(text);
      if (!mounted) return;
      setState(() => _msgs.add(_Msg(fromUser: false, text: reply)));
      if (_speakReplies) {
        _voice.speak(reply); // fire-and-forget: chat stays responsive
      }
    } on OpenRouterException catch (e) {
      if (!mounted) return;
      setState(() => _msgs
          .add(_Msg(fromUser: false, text: e.message, isError: true)));
    } catch (e) {
      if (!mounted) return;
      setState(() => _msgs.add(
          _Msg(fromUser: false, text: 'Something went wrong: $e', isError: true)));
    } finally {
      if (mounted) setState(() => _sending = false);
      _scrollToEnd();
    }
  }

  // --------------------------------------------------------------- photo

  Future<void> _pickImage() async {
    final ImageSource? source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: const Color(0xFF120A1F),
      builder: (BuildContext ctx) => SafeArea(
        child: Wrap(
          children: <Widget>[
            ListTile(
              leading: const Icon(Icons.photo_camera, color: Colors.white70),
              title: const Text('Take a photo'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Colors.white70),
              title: const Text('Choose from gallery'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;

    try {
      final XFile? file = await _picker.pickImage(
        source: source,
        maxWidth: 1600,
        maxHeight: 1600,
        imageQuality: 85,
      );
      if (file != null && mounted) {
        setState(() => _pendingImage = File(file.path));
      }
    } catch (e) {
      if (mounted) _toast('Could not open the image: $e');
    }
  }

  // --------------------------------------------------------------- voice

  Future<void> _toggleMic() async {
    if (_sending) return;
    if (_listening) {
      await _voice.stopListening();
      if (mounted) setState(() => _listening = false);
      return;
    }
    try {
      setState(() => _listening = true);
      await _voice.startListening(
        onText: (String words, bool isFinal) {
          if (!mounted) return;
          setState(() {
            _input.text = words;
            _input.selection =
                TextSelection.collapsed(offset: words.length);
          });
          if (isFinal && words.trim().isNotEmpty) {
            setState(() => _listening = false);
            _send();
          }
        },
      );
    } on VoiceException catch (e) {
      if (mounted) {
        setState(() => _listening = false);
        _toast(e.message);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _listening = false);
        _toast('Voice input failed: $e');
      }
    }
  }

  void _clearChat() {
    _voice.stopSpeaking();
    _ai.resetConversation();
    setState(() {
      _msgs.clear();
      _pendingImage = null;
    });
  }

  // ------------------------------------------------------------------ UI

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07020D),
      appBar: AppBar(
        title: const Text('Zentro AI'),
        backgroundColor: const Color(0xFF120A1F),
        actions: <Widget>[
          IconButton(
            tooltip: _speakReplies ? 'Mute spoken replies' : 'Speak replies',
            icon: Icon(_speakReplies ? Icons.volume_up : Icons.volume_off),
            onPressed: () {
              setState(() => _speakReplies = !_speakReplies);
              if (!_speakReplies) _voice.stopSpeaking();
            },
          ),
          IconButton(
            tooltip: 'New chat',
            icon: const Icon(Icons.delete_outline),
            onPressed: _msgs.isEmpty ? null : _clearChat,
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          _topLogo(),
          Expanded(
            child: _msgs.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Type, tap the mic to speak, or add a photo and ask about it.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white54),
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.all(12),
                    itemCount: _msgs.length + (_sending ? 1 : 0),
                    itemBuilder: (BuildContext context, int i) {
                      if (i == _msgs.length) return const _TypingBubble();
                      return _Bubble(msg: _msgs[i]);
                    },
                  ),
          ),
          if (_pendingImage != null) _pendingPreview(),
          _inputBar(),
        ],
      ),
    );
  }

  Widget _topLogo() {
    return SizedBox(
      height: 126,
      child: Center(
        child: AnimatedBuilder(
          animation: _logoController,
          builder: (BuildContext context, Widget? child) {
            final double angle = _logoController.value * math.pi * 2;

            return Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, 0.0015)
                ..rotateY(angle)
                ..rotateX(math.sin(angle) * 0.04),
              child: child,
            );
          },
          child: Container(
            width: 92,
            height: 92,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const SweepGradient(
                colors: <Color>[
                  Color(0xFFFF1493),
                  Color(0xFFFFA726),
                  Color(0xFF3949FF),
                  Color(0xFF8E2DE2),
                  Color(0xFFFF1493),
                ],
              ),
              boxShadow: const <BoxShadow>[
                BoxShadow(
                  color: Color(0x664F2BFF),
                  blurRadius: 22,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Center(
              child: Container(
                width: 70,
                height: 70,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xFF07020D),
                ),
                child: Stack(
                  clipBehavior: Clip.none,
                  children: <Widget>[
                    Positioned(
                      top: 2,
                      right: 2,
                      child: Container(
                        width: 14,
                        height: 14,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: <Color>[
                              Color(0xFF7C4DFF),
                              Color(0xFF304FFE),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _pendingPreview() {
    return Container(
      color: const Color(0xFF120A1F),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      alignment: Alignment.centerLeft,
      child: Stack(
        children: <Widget>[
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(_pendingImage!,
                height: 80, width: 80, fit: BoxFit.cover),
          ),
          Positioned(
            top: 0,
            right: 0,
            child: GestureDetector(
              onTap: () => setState(() => _pendingImage = null),
              child: const CircleAvatar(
                radius: 10,
                backgroundColor: Colors.black87,
                child: Icon(Icons.close, size: 14, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _inputBar() {
    return Container(
      color: const Color(0xFF120A1F),
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
      child: SafeArea(
        top: false,
        child: Row(
          children: <Widget>[
            IconButton(
              icon: const Icon(Icons.add_photo_alternate_outlined,
                  color: Colors.white70),
              onPressed: _sending ? null : _pickImage,
            ),
            Expanded(
              child: TextField(
                controller: _input,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: _listening ? 'Listening…' : 'Message',
                  hintStyle: const TextStyle(color: Colors.white38),
                  filled: true,
                  fillColor: Colors.white10,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(22),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            IconButton(
              icon: Icon(_listening ? Icons.stop_circle : Icons.mic,
                  color: _listening ? Colors.redAccent : Colors.white70),
              onPressed: _toggleMic,
            ),
            IconButton(
              icon: const Icon(Icons.send, color: _accent),
              onPressed: _sending ? null : _send,
            ),
          ],
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  final _Msg msg;
  const _Bubble({Key? key, required this.msg}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool user = msg.fromUser;
    final Color bg = msg.isError
        ? const Color(0xFF4A1620)
        : user
            ? const Color(0xFFFF1493)
            : const Color(0xFF241638);

    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(10),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (msg.image != null)
              Padding(
                padding: EdgeInsets.only(bottom: msg.text.isEmpty ? 0 : 8),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.file(msg.image!,
                      width: 220, height: 220, fit: BoxFit.cover),
                ),
              ),
            if (msg.text.isNotEmpty)
              SelectableText(msg.text,
                  style: const TextStyle(color: Colors.white, height: 1.35)),
          ],
        ),
      ),
    );
  }
}

class _TypingBubble extends StatelessWidget {
  const _TypingBubble({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF241638),
          borderRadius: BorderRadius.circular(16),
        ),
        child: const SizedBox(
          width: 18,
          height: 18,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      ),
    );
  }
}
