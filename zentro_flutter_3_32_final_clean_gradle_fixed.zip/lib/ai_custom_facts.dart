// ============================================================
// CLOUD AI — CUSTOM FIXED FACTS / ANSWERS
// ============================================================
// This file lets the Cloud AI answer a few specific questions with an
// EXACT, guaranteed-correct reply — instantly, with no Gemini API call
// at all. That makes these answers both 100% correct every time AND
// instant (no network wait).
//
// Any other question the user asks still goes to the real Gemini AI as
// normal (see ai_help_assistant_screen.dart / gemini_chat_service.dart).
//
// HOW TO ADD MORE FIXED ANSWERS LATER:
// Copy one of the blocks below (a "trigger" check + a "return") and edit
// the keywords and the reply text.
// ============================================================

class AiCustomFacts {
  /// Returns a fixed reply if [message] matches one of the known
  /// questions below, otherwise returns null (meaning: let Gemini answer
  /// normally).
  static String? match(String message) {
    final m = message.toLowerCase().trim();

    // ---- 1) Islamic greeting -> greet back ----
    // Matches "Assalamu Alaikum", "Asslam Alekum", "Salam", etc.
    if (m.contains('alekum') ||
        m.contains('alaikum') ||
        m.contains('assalam') ||
        m.contains('asslam') ||
        m == 'salam' ||
        m.startsWith('salam ')) {
      return "Walekum Assalam! 🌙 Kaise ho aap? Zentro Cloud AI se kuch bhi pooch sakte ho.";
    }

    // ---- 2) "Duniya ka malik kaun hai?" / "Who is the owner/master of this world?" ----
    final asksWorldOwner = (m.contains('duniya') || m.contains('world')) &&
        (m.contains('malik') ||
            m.contains('maalik') ||
            m.contains('owner') ||
            m.contains('master') ||
            m.contains('rab') ||
            m.contains('god'));
    if (asksWorldOwner) {
      return "Is duniya ka malik Allah hai.";
    }

    // ---- 3) "Zentro ka founder/foundation kaun hai?" ----
    final asksZentroFounder = m.contains('zentro') &&
        (m.contains('found') || // founder, foundation
            m.contains('banaya') ||
            m.contains('banane wala') ||
            m.contains('owner') ||
            m.contains('malik') ||
            m.contains('creator'));
    if (asksZentroFounder) {
      return "Zentro ka founder Noushad Alam hai.";
    }

    // ---- 4) "Noushad Alam / founder ka janm kaha hua?" (birthplace) ----
    final asksFounderBirthplace =
        (m.contains('noushad') || m.contains('founder')) &&
            (m.contains('janm') ||
                m.contains('paida') ||
                m.contains('born') ||
                m.contains('birth'));
    if (asksFounderBirthplace) {
      return "Noushad Alam ka janm Mumbai mein hua — lekin asal mein unka janm Jharkhand mein hua tha, baad mein woh Mumbai shift ho gaye.";
    }

    return null; // no fixed answer — let Gemini handle it normally
  }

  /// Extra facts given to the real Gemini model as background context, so
  /// even if the user asks the same things in a different way (different
  /// wording/language than the exact matches above), the AI still answers
  /// consistently with these facts instead of guessing or contradicting
  /// them.
  static const String systemPersona =
      "You are 'Cloud AI', the built-in assistant inside the Zentro app. "
      "Follow these facts exactly whenever they are relevant, and never "
      "contradict them:\n"
      "1. If the user greets you with an Islamic greeting (Assalamu Alaikum / "
      "Asslam Alekum / Salam), greet them back warmly with 'Walekum Assalam' "
      "before continuing.\n"
      "2. If asked who is the owner/master of this world ('duniya ka malik "
      "kaun hai'), the answer is: Allah.\n"
      "3. If asked who is the founder of Zentro, the answer is: Noushad Alam.\n"
      "4. If asked where Noushad Alam (Zentro's founder) was born: he was "
      "originally born in Jharkhand, and later shifted to Mumbai, where he "
      "lives now.\n"
      "Answer naturally in the same language/style (Hindi/Urdu/English mix, "
      "i.e. Hinglish) the user writes in. For anything outside these facts, "
      "answer normally and honestly as a helpful assistant.";
}
