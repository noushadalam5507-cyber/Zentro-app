import 'package:flutter/material.dart';
import 'gemini_chat_service.dart';
import 'rewarded_ad_service.dart';
import 'ai_custom_facts.dart';

// Cloud AI chat — backed by the real Gemini API (see gemini_chat_service.dart
// and gemini_config.dart for the API key). Replies stream in word-by-word
// as they're generated, so it feels fast and alive rather than a long wait
// followed by a wall of text.
class AiHelpAssistantScreen extends StatefulWidget {
  const AiHelpAssistantScreen({Key? key}) : super(key: key);

  @override
  State<AiHelpAssistantScreen> createState() => _AiHelpAssistantScreenState();
}

class _AiHelpAssistantScreenState extends State<AiHelpAssistantScreen> {
  final GeminiChatService _chatService = GeminiChatService();
  final RewardedAdService _rewardedAdService = RewardedAdService();
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<_ChatMessage> _messages = [];
  bool _isTyping = false;
  bool _isGeneratingMedia = false;

  @override
  void initState() {
    super.initState();
    _rewardedAdService.preload(); // have an ad ready before the user asks
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    });
  }

  /// Builds the last few turns as context so the AI remembers what was
  /// just said instead of answering every message cold.
  List<GeminiTurn> _recentHistory() {
    final turns = _messages
        .where((m) => m.text.isNotEmpty)
        .map((m) => GeminiTurn(m.isUser ? "user" : "model", m.text))
        .toList();
    // Cap context to the last 20 turns — keeps replies fast and cheap
    // instead of re-sending the whole chat history on every message.
    if (turns.length > 20) {
      return turns.sublist(turns.length - 20);
    }
    return turns;
  }

  /// FREE — real Gemini reply, streamed in live as it's generated.
  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    setState(() {
      _messages.add(_ChatMessage(text: text, isUser: true));
      _controller.clear();
    });
    _scrollToBottom();

    // Fixed/guaranteed answers (greeting, founder, etc.) — answered
    // instantly with no Gemini API call at all, so these are always
    // exactly right AND immediate.
    final fixedReply = AiCustomFacts.match(text);
    if (fixedReply != null) {
      setState(() {
        _messages.add(_ChatMessage(text: fixedReply, isUser: false));
      });
      _scrollToBottom();
      return;
    }

    final history = _recentHistory();

    setState(() {
      _messages.add(_ChatMessage(text: '', isUser: false)); // fills in live
      _isTyping = true;
    });
    _scrollToBottom();

    final replyIndex = _messages.length - 1;
    var receivedFirstChunk = false;

    await for (final chunk in _chatService.streamMessage(text, history: history)) {
      if (!mounted) return;
      setState(() {
        _messages[replyIndex] = _ChatMessage(
          text: _messages[replyIndex].text + chunk,
          isUser: false,
        );
        if (!receivedFirstChunk) {
          _isTyping = false;
          receivedFirstChunk = true;
        }
      });
      _scrollToBottom();
    }

    if (mounted) setState(() => _isTyping = false);
  }

  /// PAID — user must watch a rewarded ad to completion before media
  /// generation runs. If they skip/close the ad early, generation never
  /// executes (no reward = no `onEarned` = no `generateMedia` call).
  Future<void> _generateMedia() async {
    final prompt = _controller.text.trim();
    if (prompt.isEmpty) return;

    setState(() {
      _messages.add(_ChatMessage(
          text: "🎬 Generate media for: \"$prompt\"", isUser: true));
      _controller.clear();
    });
    _scrollToBottom();

    await _rewardedAdService.showAndRun(
      onEarned: () async {
        setState(() => _isGeneratingMedia = true);
        final result = await _chatService.generateMedia(prompt);
        if (!mounted) return;
        setState(() {
          _messages.add(_ChatMessage(text: result, isUser: false));
          _isGeneratingMedia = false;
        });
        _scrollToBottom();
      },
      onNoAdAvailable: () {
        setState(() {
          _messages.add(_ChatMessage(
            text:
                "No ad is available right now — please try again in a moment.",
            isUser: false,
          ));
        });
        _scrollToBottom();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Cloud AI")),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                final isEmptyPendingReply =
                    !msg.isUser && msg.text.isEmpty && index == _messages.length - 1;
                return Align(
                  alignment: msg.isUser
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(12),
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.78,
                    ),
                    decoration: BoxDecoration(
                      color: msg.isUser
                          ? const Color(0xFFFF1493)
                          : Colors.white12,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: isEmptyPendingReply
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Text(
                            msg.text,
                            style: const TextStyle(color: Colors.white),
                          ),
                  ),
                );
              },
            ),
          ),
          if (_isTyping || _isGeneratingMedia)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                _isGeneratingMedia ? "Generating media..." : "Cloud AI is typing...",
                style: const TextStyle(color: Colors.white54),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: "Ask a question, or describe media to generate...",
                      hintStyle: TextStyle(color: Colors.white54),
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                IconButton(
                  tooltip: "Send (free)",
                  icon: const Icon(Icons.send, color: Color(0xFFFF1493)),
                  onPressed: _send,
                ),
                IconButton(
                  tooltip: "Generate Photo/Video (watch ad)",
                  icon: const Icon(Icons.auto_awesome, color: Colors.amber),
                  onPressed: _isGeneratingMedia ? null : _generateMedia,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatMessage {
  final String text;
  final bool isUser;
  _ChatMessage({required this.text, required this.isUser});
}
