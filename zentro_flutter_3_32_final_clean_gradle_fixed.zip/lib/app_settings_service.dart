import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Persisted, device-local app settings. Every value here is actually read
/// somewhere in the app (main.dart, camera_screen, video_call_screen,
/// chat_screen, usage_time_service).
class AppSettingsService {
  static const _voiceNavKey = 'voice_nav_enabled';
  static const _textScaleKey = 'text_scale';
  static const _boldKey = 'bold_text';
  static const _camQualityKey = 'camera_quality'; // standard | high | max
  static const _callQualityKey = 'call_quality'; // saver | auto | high
  static const _hiddenWordsKey = 'hidden_words';
  static const _hiddenOnKey = 'hidden_words_on';
  static const _limitKey = 'daily_limit_minutes';
  static const _usageKey = 'usage_seconds_by_day';

  /// Listened to by MaterialApp.builder in main.dart.
  static final ValueNotifier<double> textScale = ValueNotifier<double>(1.0);
  static final ValueNotifier<bool> boldText = ValueNotifier<bool>(false);

  /// Call once in main() before runApp().
  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    textScale.value = p.getDouble(_textScaleKey) ?? 1.0;
    boldText.value = p.getBool(_boldKey) ?? false;
  }

  // ---- voice nav ----
  static Future<bool> isVoiceNavEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_voiceNavKey) ?? false;
  }

  static Future<void> setVoiceNavEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_voiceNavKey, value);
  }

  // ---- accessibility ----
  static Future<void> setTextScale(double v) async {
    textScale.value = v;
    final p = await SharedPreferences.getInstance();
    await p.setDouble(_textScaleKey, v);
  }

  static Future<void> setBoldText(bool v) async {
    boldText.value = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool(_boldKey, v);
  }

  // ---- media quality ----
  static Future<String> getCameraQuality() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_camQualityKey) ?? 'high';
  }

  static Future<void> setCameraQuality(String v) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_camQualityKey, v);
  }

  static Future<String> getCallQuality() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_callQualityKey) ?? 'auto';
  }

  static Future<void> setCallQuality(String v) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_callQualityKey, v);
  }

  // ---- hidden words ----
  static Future<bool> isHiddenWordsOn() async {
    final p = await SharedPreferences.getInstance();
    return p.getBool(_hiddenOnKey) ?? true;
  }

  static Future<void> setHiddenWordsOn(bool v) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_hiddenOnKey, v);
  }

  static Future<List<String>> getHiddenWords() async {
    final p = await SharedPreferences.getInstance();
    return p.getStringList(_hiddenWordsKey) ?? <String>[];
  }

  static Future<void> setHiddenWords(List<String> words) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_hiddenWordsKey, words);
  }

  // ---- time management ----
  /// 0 = no limit.
  static Future<int> getDailyLimitMinutes() async {
    final p = await SharedPreferences.getInstance();
    return p.getInt(_limitKey) ?? 0;
  }

  static Future<void> setDailyLimitMinutes(int minutes) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(_limitKey, minutes);
  }

  static Future<Map<String, int>> getUsageMap() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_usageKey);
    if (raw == null) return <String, int>{};
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      return decoded.map((k, v) => MapEntry(k, (v as num).toInt()));
    } catch (_) {
      return <String, int>{};
    }
  }

  static Future<int> getUsageSeconds(String dayKey) async {
    final m = await getUsageMap();
    return m[dayKey] ?? 0;
  }

  static Future<void> setUsageSeconds(String dayKey, int seconds) async {
    final p = await SharedPreferences.getInstance();
    final m = await getUsageMap();
    m[dayKey] = seconds;
    // keep only the latest 30 days
    if (m.length > 30) {
      final keys = m.keys.toList()..sort();
      for (final k in keys.take(m.length - 30)) {
        m.remove(k);
      }
    }
    await p.setString(_usageKey, jsonEncode(m));
  }
}
