import 'package:file_picker/file_picker.dart';

/// LITE BUILD: `ffmpeg_kit_flutter_minimal` has been removed from
/// pubspec.yaml to keep the app buildable on lightweight online builders
/// like FlutLab (its native binary was the single biggest build-failure
/// risk). Picking a real .mp3 still works below; the actual audio-into-video
/// re-encode is disabled and clearly reported as such rather than silently
/// pretending it happened.
///
/// To re-enable real mixing once the rest of the app builds cleanly:
///   1. Add back to pubspec.yaml:  ffmpeg_kit_flutter_minimal: ^6.0.8
///   2. Restore the FFmpegKit import + muxAudioIntoVideo() body from the
///      previous "full" build (see SETUP_INSTRUCTIONS.md).
class AudioMixService {
  static const bool mixingAvailable = false;

  /// Opens the native file picker restricted to audio files and returns the
  /// picked file's real path on disk, or null if the user cancelled.
  static Future<String?> pickMp3() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3'],
    );
    if (result == null || result.files.single.path == null) return null;
    return result.files.single.path;
  }

  /// LITE build: does not actually mix. Returns the original video path
  /// unchanged so the recording flow still completes normally; the caller
  /// (camera_screen.dart) checks [mixingAvailable] first and tells the user
  /// plainly that mixing isn't available in this build, instead of this
  /// function faking a success.
  static Future<String> muxAudioIntoVideo({
    required String videoPath,
    required String audioPath,
  }) async {
    return videoPath;
  }
}
