import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  // ---------------- GOOGLE (unchanged) ----------------

  Future<User?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null; // user cancelled

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await _auth.signInWithCredential(credential);
      return userCredential.user;
    } catch (e) {
      // ignore: avoid_print
      print("Sign-in error: $e");
      return null;
    }
  }

  // ---------------- EMAIL + PASSWORD ----------------

  /// Creates a brand-new account from Full Name + Email + Password.
  /// Throws [FirebaseAuthException] on failure (see [friendlyError]).
  Future<User> signUpWithEmail({
    required String name,
    required String email,
    required String password,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = cred.user!;
    await user.updateDisplayName(name.trim());
    await user.reload(); // so displayName is visible on currentUser
    return _auth.currentUser!;
  }

  /// Logs an existing email/password user in.
  /// Throws [FirebaseAuthException] on failure (see [friendlyError]).
  Future<User> signInWithEmail({
    required String email,
    required String password,
  }) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    return cred.user!;
  }

  /// Turns Firebase's error codes into short messages a user can act on.
  static String friendlyError(Object e) {
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'email-already-in-use':
          return 'This email already has an account. Try signing in instead.';
        case 'invalid-email':
          return 'That email address doesn\'t look right.';
        case 'weak-password':
          return 'Password is too weak — use at least 6 characters.';
        case 'user-not-found':
        case 'wrong-password':
        case 'invalid-credential':
        case 'invalid-login-credentials':
          return 'Wrong email or password.';
        case 'user-disabled':
          return 'This account has been disabled.';
        case 'too-many-requests':
          return 'Too many attempts. Please wait a bit and try again.';
        case 'network-request-failed':
          return 'No internet connection. Please check your network.';
        case 'operation-not-allowed':
          return 'Email sign-in isn\'t enabled yet. Turn on "Email/Password" '
              'in Firebase Console → Authentication → Sign-in method.';
        default:
          return e.message ?? 'Sign-in failed. Please try again.';
      }
    }
    return 'Something went wrong. Please try again.';
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }

  User? get currentUser => _auth.currentUser;
}
