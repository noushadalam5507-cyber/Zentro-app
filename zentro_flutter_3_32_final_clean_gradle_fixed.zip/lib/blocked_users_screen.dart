import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'privacy_service.dart';

class BlockedUsersScreen extends StatelessWidget {
  const BlockedUsersScreen({Key? key}) : super(key: key);

  Future<String> _nameOf(String uid) async {
    try {
      final doc =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final d = doc.data();
      final name = (d?['displayName'] ?? '').toString();
      if (name.isNotEmpty) return name;
      final email = (d?['email'] ?? '').toString();
      return email.isNotEmpty ? email : uid;
    } catch (_) {
      return uid;
    }
  }

  @override
  Widget build(BuildContext context) {
    final privacy = PrivacyService();
    return Scaffold(
      appBar: AppBar(title: const Text("ब्लॉक किए गए लोग")),
      body: StreamBuilder(
        stream: privacy.blockedUsersStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(
              child: Text(
                "आपने किसी को ब्लॉक नहीं किया है।",
                style: TextStyle(color: Colors.white54),
              ),
            );
          }
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final blockedUid = docs[index].id;
              return ListTile(
                leading: const Icon(Icons.person, color: Colors.white70),
                title: FutureBuilder<String>(
                  future: _nameOf(blockedUid),
                  builder: (c, s) => Text(s.data ?? blockedUid,
                      style: const TextStyle(color: Colors.white)),
                ),
                trailing: TextButton(
                  onPressed: () => privacy.unblockUser(blockedUid),
                  child: const Text("अनब्लॉक"),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
