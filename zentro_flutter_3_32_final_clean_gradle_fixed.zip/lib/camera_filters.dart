import 'package:flutter/material.dart';

/// A single selectable camera filter.
///
/// IMPORTANT / HONEST LIMITATION:
/// These are real-time colour-grade filters (contrast, warmth, saturation,
/// brightness) applied as a `ColorFilter` over the live camera preview and
/// over captured photos/video frames — they genuinely run on the real
/// hardware feed, nothing here is a mock.
///
/// They are NOT face-tracking AR filters (no beauty smoothing, no face
/// landmarks, no masks/ears/etc). True Snapchat/Instagram-style face AR
/// requires a dedicated face-mesh SDK (e.g. Google ML Kit Face Detection,
/// or a commercial SDK like Banuba/DeepAR) integrated natively — that is a
/// separate, much larger piece of work than can be dropped into a single
/// Dart file. This module is structured so a real face-AR SDK can be slotted
/// in later behind the same `CameraFilter` interface without reworking the
/// camera screen.
class CameraFilter {
  final String name;
  final IconData icon;
  final ColorFilter matrix;

  const CameraFilter(this.name, this.icon, this.matrix);
}

const List<CameraFilter> kCameraFilters = [
  CameraFilter(
    'Normal',
    Icons.circle_outlined,
    ColorFilter.matrix(<double>[
      1, 0, 0, 0, 0,
      0, 1, 0, 0, 0,
      0, 0, 1, 0, 0,
      0, 0, 0, 1, 0,
    ]),
  ),
  CameraFilter(
    'Soft Glow', // gentle brightness lift + lower contrast, a cheap
    Icons.wb_sunny_outlined, // "smoothing" look without real face tracking
    ColorFilter.matrix(<double>[
      1.05, 0, 0, 0, 12,
      0, 1.05, 0, 0, 12,
      0, 0, 1.05, 0, 12,
      0, 0, 0, 1, 0,
    ]),
  ),
  CameraFilter(
    'Warm',
    Icons.local_fire_department_outlined,
    ColorFilter.matrix(<double>[
      1.15, 0, 0, 0, 8,
      0, 1.05, 0, 0, 0,
      0, 0, 0.90, 0, 0,
      0, 0, 0, 1, 0,
    ]),
  ),
  CameraFilter(
    'Cool',
    Icons.ac_unit,
    ColorFilter.matrix(<double>[
      0.92, 0, 0, 0, 0,
      0, 1.0, 0, 0, 0,
      0, 0, 1.18, 0, 10,
      0, 0, 0, 1, 0,
    ]),
  ),
  CameraFilter(
    'Vivid',
    Icons.auto_awesome,
    ColorFilter.matrix(<double>[
      1.3, -0.1, -0.1, 0, 0,
      -0.1, 1.3, -0.1, 0, 0,
      -0.1, -0.1, 1.3, 0, 0,
      0, 0, 0, 1, 0,
    ]),
  ),
  CameraFilter(
    'Mono',
    Icons.filter_b_and_w,
    ColorFilter.matrix(<double>[
      0.33, 0.33, 0.33, 0, 0,
      0.33, 0.33, 0.33, 0, 0,
      0.33, 0.33, 0.33, 0, 0,
      0, 0, 0, 1, 0,
    ]),
  ),
];
