import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import 'camera_filters.dart';
import 'audio_mix_service.dart';
import 'voice_control_service.dart';
import 'app_settings_service.dart';

/// Real native camera capture screen used for Reels/Stories.
///
/// Permission + init flow is written specifically so the screen never shows
/// a blank/black surface:
///   1. Show an explicit "requesting permission" loader.
///   2. Only after permission is actually granted do we create the
///      CameraController and await `initialize()`.
///   3. Only after `initialize()` resolves do we build the `CameraPreview`.
///   4. If permission is denied, we show a real "open settings" screen
///      instead of a blank camera surface.
/// A camera surface is never mounted before the controller is ready.
class CameraScreen extends StatefulWidget {
  const CameraScreen({Key? key}) : super(key: key);

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

enum _CameraLoadState { requestingPermission, permissionDenied, initializing, ready, error }

class _CameraScreenState extends State<CameraScreen> with WidgetsBindingObserver {
  CameraController? _controller;
  List<CameraDescription> _cameras = [];
  int _cameraIndex = 0;
  _CameraLoadState _state = _CameraLoadState.requestingPermission;
  String? _errorMessage;

  CameraFilter _selectedFilter = kCameraFilters.first;
  bool _isRecording = false;
  String? _pickedAudioPath;

  final VoiceControlService _voice = VoiceControlService();
  bool _voiceNavEnabled = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _bootstrap();
    // Respect the Settings > Voice-Controlled Reel Navigation toggle as the
    // default for this session; the on-screen mic button can still override
    // it live without touching the saved setting.
    AppSettingsService.isVoiceNavEnabled().then((enabled) {
      if (enabled && mounted) _toggleVoiceNav();
    });
  }

  Future<void> _bootstrap() async {
    setState(() => _state = _CameraLoadState.requestingPermission);

    final camStatus = await Permission.camera.request();
    final micStatus = await Permission.microphone.request();

    if (!camStatus.isGranted || !micStatus.isGranted) {
      setState(() => _state = _CameraLoadState.permissionDenied);
      return;
    }

    await _initCamera();
  }

  Future<void> _initCamera() async {
    setState(() => _state = _CameraLoadState.initializing);
    try {
      _cameras = await availableCameras();
      if (_cameras.isEmpty) {
        setState(() {
          _state = _CameraLoadState.error;
          _errorMessage = 'No camera hardware found on this device.';
        });
        return;
      }

      // Prefer the front camera for Reels/Stories, like Instagram/Snapchat.
      _cameraIndex = _cameras.indexWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
      );
      if (_cameraIndex == -1) _cameraIndex = 0;

      await _openController(_cameras[_cameraIndex]);
    } catch (e) {
      setState(() {
        _state = _CameraLoadState.error;
        _errorMessage = e.toString();
      });
    }
  }

  Future<void> _openController(CameraDescription description) async {
    final quality = await AppSettingsService.getCameraQuality();
    final preset = quality == 'standard'
        ? ResolutionPreset.medium
        : (quality == 'max' ? ResolutionPreset.veryHigh : ResolutionPreset.high);
    final previous = _controller;
    final controller = CameraController(
      description,
      preset,
      enableAudio: true,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );
    _controller = controller;

    try {
      await controller.initialize();
      await previous?.dispose();
      if (!mounted) return;
      setState(() => _state = _CameraLoadState.ready);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _state = _CameraLoadState.error;
        _errorMessage = e.toString();
      });
    }
  }

  Future<void> _flipCamera() async {
    if (_cameras.length < 2) return;
    _cameraIndex = (_cameraIndex + 1) % _cameras.length;
    setState(() => _state = _CameraLoadState.initializing);
    await _openController(_cameras[_cameraIndex]);
  }

  Future<void> _pickAudio() async {
    final path = await AudioMixService.pickMp3();
    if (path != null) {
      setState(() => _pickedAudioPath = path);
      if (mounted) {
        final note = AudioMixService.mixingAvailable
            ? ''
            : ' (mixing disabled in this build — video saves without it)';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Audio track selected: ${path.split('/').last}$note')),
        );
      }
    }
  }

  Future<void> _toggleRecording() async {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;

    if (_isRecording) {
      final file = await controller.stopVideoRecording();
      setState(() => _isRecording = false);

      String finalPath = file.path;
      if (_pickedAudioPath != null) {
        if (!AudioMixService.mixingAvailable) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text(
                  'Audio mixing isn\'t available in this build — saved '
                  'the video without the custom track.',
                ),
                duration: Duration(seconds: 4),
              ),
            );
          }
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Mixing your audio track into the video…')),
            );
          }
          finalPath = await AudioMixService.muxAudioIntoVideo(
            videoPath: file.path,
            audioPath: _pickedAudioPath!,
          );
        }
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Saved: $finalPath')),
        );
      }
    } else {
      await controller.prepareForVideoRecording();
      await controller.startVideoRecording();
      setState(() => _isRecording = true);
    }
  }

  Future<void> _toggleVoiceNav() async {
    if (_voiceNavEnabled) {
      await _voice.stop();
      setState(() => _voiceNavEnabled = false);
      return;
    }
    final available = await _voice.start(
      onUp: () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Voice: previous'), duration: Duration(milliseconds: 600)),
      ),
      onDown: () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Voice: next'), duration: Duration(milliseconds: 600)),
      ),
    );
    setState(() => _voiceNavEnabled = available);
    if (!available && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Speech recognition unavailable on this device.')),
      );
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState appState) {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    if (appState == AppLifecycleState.inactive) {
      controller.dispose();
    } else if (appState == AppLifecycleState.resumed) {
      _openController(controller.description);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    _voice.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: switch (_state) {
          _CameraLoadState.requestingPermission => const _CenteredMessage(
              icon: Icons.videocam_outlined,
              title: 'Requesting camera & microphone access…',
            ),
          _CameraLoadState.permissionDenied => _PermissionDeniedView(
              onRetry: _bootstrap,
            ),
          _CameraLoadState.initializing => const _CenteredMessage(
              icon: Icons.hourglass_top,
              title: 'Starting camera…',
            ),
          _CameraLoadState.error => _CenteredMessage(
              icon: Icons.error_outline,
              title: 'Camera error',
              subtitle: _errorMessage,
              action: TextButton(onPressed: _initCamera, child: const Text('Retry')),
            ),
          _CameraLoadState.ready => _buildReadyView(),
        },
      ),
    );
  }

  Widget _buildReadyView() {
    final controller = _controller!;
    return Stack(
      fit: StackFit.expand,
      children: [
        ColorFiltered(
          colorFilter: _selectedFilter.matrix,
          child: CameraPreview(controller),
        ),

        // Top bar: close, flip camera, voice-nav toggle.
        Positioned(
          top: 8,
          left: 8,
          right: 8,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _RoundIconButton(icon: Icons.close, onTap: () => Navigator.pop(context)),
              Row(
                children: [
                  _RoundIconButton(
                    icon: _voiceNavEnabled ? Icons.mic : Icons.mic_off,
                    onTap: _toggleVoiceNav,
                    highlighted: _voiceNavEnabled,
                  ),
                  const SizedBox(width: 8),
                  _RoundIconButton(icon: Icons.cameraswitch, onTap: _flipCamera),
                ],
              ),
            ],
          ),
        ),

        // Filter strip.
        Positioned(
          bottom: 150,
          left: 0,
          right: 0,
          child: SizedBox(
            height: 76,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: kCameraFilters.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, i) {
                final f = kCameraFilters[i];
                final selected = f.name == _selectedFilter.name;
                return GestureDetector(
                  onTap: () => setState(() => _selectedFilter = f),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.black45,
                          border: Border.all(
                            color: selected ? const Color(0xFFFF1493) : Colors.white38,
                            width: selected ? 2.5 : 1,
                          ),
                        ),
                        child: Icon(f.icon, color: Colors.white),
                      ),
                      const SizedBox(height: 4),
                      Text(f.name, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                    ],
                  ),
                );
              },
            ),
          ),
        ),

        // Bottom bar: pick audio + record button.
        Positioned(
          bottom: 24,
          left: 0,
          right: 0,
          child: Column(
            children: [
              if (_pickedAudioPath != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Chip(
                    avatar: const Icon(Icons.music_note, size: 16),
                    label: Text(_pickedAudioPath!.split('/').last,
                        overflow: TextOverflow.ellipsis),
                    onDeleted: () => setState(() => _pickedAudioPath = null),
                  ),
                ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _RoundIconButton(icon: Icons.music_note, onTap: _pickAudio),
                  const SizedBox(width: 28),
                  GestureDetector(
                    onTap: _toggleRecording,
                    child: Container(
                      width: 78,
                      height: 78,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 4),
                      ),
                      child: Center(
                        child: Container(
                          width: _isRecording ? 30 : 62,
                          height: _isRecording ? 30 : 62,
                          decoration: BoxDecoration(
                            color: Colors.redAccent,
                            borderRadius:
                                BorderRadius.circular(_isRecording ? 8 : 40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 28),
                  const SizedBox(width: 44), // symmetry spacer
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _CenteredMessage extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? action;

  const _CenteredMessage({
    required this.icon,
    required this.title,
    this.subtitle,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white54, size: 42),
          const SizedBox(height: 16),
          Text(title,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              textAlign: TextAlign.center),
          if (subtitle != null) ...[
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(subtitle!,
                  style: const TextStyle(color: Colors.white38, fontSize: 12),
                  textAlign: TextAlign.center),
            ),
          ],
          if (action != null) ...[const SizedBox(height: 12), action!],
        ],
      ),
    );
  }
}

class _PermissionDeniedView extends StatelessWidget {
  final VoidCallback onRetry;
  const _PermissionDeniedView({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.no_photography_outlined, color: Colors.white54, size: 42),
            const SizedBox(height: 16),
            const Text(
              'Camera & microphone access is required to record Reels/Stories.',
              style: TextStyle(color: Colors.white, fontSize: 15),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OutlinedButton(onPressed: onRetry, child: const Text('Try again')),
                const SizedBox(width: 12),
                ElevatedButton(
                  onPressed: () => openAppSettings(),
                  child: const Text('Open Settings'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool highlighted;

  const _RoundIconButton({
    required this.icon,
    required this.onTap,
    this.highlighted = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: highlighted ? const Color(0xFFFF1493) : Colors.black45,
        ),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }
}
