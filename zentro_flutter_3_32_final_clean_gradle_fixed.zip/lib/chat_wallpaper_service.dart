import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A selectable chat wallpaper — either one of a few built-in gradients, or
/// a real photo the user picked from their own gallery (path stored on
/// device, per chatId, via SharedPreferences).
class ChatWallpaper {
  final String id;
  final String label;
  final Gradient? gradient;

  const ChatWallpaper.preset(this.id, this.label, this.gradient);
  const ChatWallpaper.custom(String imagePath)
      : id = 'custom:$imagePath',
        label = 'Custom photo',
        gradient = null;

  bool get isCustom => id.startsWith('custom:');
  String? get imagePath => isCustom ? id.substring(7) : null;
}

const List<ChatWallpaper> kPresetWallpapers = [
  ChatWallpaper.preset('default', 'Default', null),
  ChatWallpaper.preset(
    'sunset',
    'Sunset',
    LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFFFF6B00), Color(0xFFFF1493)],
    ),
  ),
  ChatWallpaper.preset(
    'nebula',
    'Nebula',
    LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFFA855F7), Color(0xFF07020D)],
    ),
  ),
  ChatWallpaper.preset(
    'ocean',
    'Ocean',
    LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF00D2FF), Color(0xFF07020D)],
    ),
  ),
  ChatWallpaper.preset(
    'midnight',
    'Midnight',
    LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E)],
    ),
  ),
];

class ChatWallpaperService {
  static String _keyFor(String chatId) => 'chat_wallpaper_$chatId';

  static Future<ChatWallpaper> get(String chatId) async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString(_keyFor(chatId));
    if (stored == null) return kPresetWallpapers.first;

    if (stored.startsWith('custom:')) {
      final path = stored.substring(7);
      // If the picked file was ever removed from disk, fall back safely
      // instead of trying to decorate with a missing image.
      if (File(path).existsSync()) {
        return ChatWallpaper.custom(path);
      }
      return kPresetWallpapers.first;
    }

    return kPresetWallpapers.firstWhere(
      (w) => w.id == stored,
      orElse: () => kPresetWallpapers.first,
    );
  }

  static Future<void> set(String chatId, ChatWallpaper wallpaper) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyFor(chatId), wallpaper.id);
  }

  /// Background decoration for the given wallpaper — real gradient or a
  /// real on-disk image, never a placeholder.
  static BoxDecoration decorationFor(ChatWallpaper wallpaper) {
    if (wallpaper.isCustom && wallpaper.imagePath != null) {
      return BoxDecoration(
        image: DecorationImage(
          image: FileImage(File(wallpaper.imagePath!)),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(
            Colors.black.withOpacity(0.35),
            BlendMode.darken,
          ),
        ),
      );
    }
    if (wallpaper.gradient != null) {
      return BoxDecoration(gradient: wallpaper.gradient);
    }
    return const BoxDecoration(color: Color(0xFF07020D));
  }
}
