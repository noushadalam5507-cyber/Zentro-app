import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'razorpay_config.dart';
import 'coin_wallet_service.dart';

class _CoinBundle {
  final int coins;
  final int pricePaise; // smallest currency unit, e.g. paise for INR
  const _CoinBundle(this.coins, this.pricePaise);
}

const List<_CoinBundle> _bundles = [
  _CoinBundle(100, 9900),   // 100 coins for ₹99
  _CoinBundle(550, 49900),  // 550 coins for ₹499
  _CoinBundle(1200, 99900), // 1200 coins for ₹999
];

/// Coins are only ever credited by your Cloud Function's payment webhook,
/// the same server-verified pattern as premium_screen.dart — never by the
/// client directly. This screen only starts checkout and displays the
/// live balance once the webhook has credited it.
class CoinStoreScreen extends StatefulWidget {
  const CoinStoreScreen({Key? key}) : super(key: key);

  @override
  State<CoinStoreScreen> createState() => _CoinStoreScreenState();
}

class _CoinStoreScreenState extends State<CoinStoreScreen> {
  late final Razorpay _razorpay;
  bool _processing = false;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _onSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _onError);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  Future<void> _buy(_CoinBundle bundle) async {
    if (RazorpayConfig.keyId == "PASTE_YOUR_RAZORPAY_KEY_ID_HERE" ||
        RazorpayConfig.createOrderEndpoint ==
            "PASTE_YOUR_CLOUD_FUNCTION_URL_HERE") {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text(
            "Razorpay isn't configured yet — set keyId and createOrderEndpoint in razorpay_config.dart, and deploy the Cloud Function (see /backend)."),
      ));
      return;
    }

    setState(() => _processing = true);
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final response = await http.post(
        Uri.parse(RazorpayConfig.createOrderEndpoint),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "uid": uid,
          "amount": bundle.pricePaise,
          "currency": RazorpayConfig.currency,
          "purpose": "coins",
          "coins": bundle.coins,
        }),
      );
      final order = jsonDecode(response.body);

      _razorpay.open({
        'key': RazorpayConfig.keyId,
        'amount': bundle.pricePaise,
        'currency': RazorpayConfig.currency,
        'name': 'Instagrand Coins',
        'description': '${bundle.coins} coins',
        'order_id': order['orderId'],
        'notes': {'uid': uid, 'coins': bundle.coins, 'purpose': 'coins'},
      });
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Could not start checkout: $e")));
    } finally {
      setState(() => _processing = false);
    }
  }

  void _onSuccess(PaymentSuccessResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text("Payment received — coins will appear shortly."),
    ));
  }

  void _onError(PaymentFailureResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Payment failed: ${response.message}")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Coin Store")),
      body: Column(
        children: [
          StreamBuilder<int>(
            stream: CoinWalletService().myBalanceStream(),
            builder: (context, snapshot) {
              return Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  "Your balance: ${snapshot.data ?? 0} coins",
                  style: const TextStyle(
                      color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
              );
            },
          ),
          Expanded(
            child: ListView(
              children: _bundles
                  .map((b) => ListTile(
                        leading: const Icon(Icons.monetization_on,
                            color: Colors.amber),
                        title: Text("${b.coins} coins",
                            style: const TextStyle(color: Colors.white)),
                        trailing: ElevatedButton(
                          onPressed: _processing ? null : () => _buy(b),
                          child: Text("₹${(b.pricePaise / 100).toStringAsFixed(0)}"),
                        ),
                      ))
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}
