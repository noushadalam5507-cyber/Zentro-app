import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Firestore structure:
///   users/{uid}.coinBalance            -> int, SERVER-WRITTEN ONLY on
///                                          credit (after a verified coin
///                                          purchase, same pattern as
///                                          isPremium in subscription_service.dart)
///   giftTransactions/{autoId}          -> { fromUid, toUid, coins, sentAt }
///
/// Spending coins (sending a gift) IS done client-side via a Firestore
/// transaction, because it only ever moves coins the user already legally
/// owns from one balance to another — it can never mint new coins. Adding
/// coins (a purchase) must NOT be done client-side; that has to go through
/// the same server-verified-payment pattern as subscriptions.
class CoinWalletService {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  String get _myUid => _auth.currentUser!.uid;

  Stream<int> myBalanceStream() {
    return _db.collection('users').doc(_myUid).snapshots().map(
          (doc) => (doc.data()?['coinBalance'] as num?)?.toInt() ?? 0,
        );
  }

  /// Moves [coins] from the current user to [hostUid] atomically. Fails
  /// (throws) if the sender doesn't have enough balance — never lets a
  /// balance go negative.
  Future<void> sendGift({required String hostUid, required int coins}) async {
    final myRef = _db.collection('users').doc(_myUid);
    final hostRef = _db.collection('users').doc(hostUid);

    await _db.runTransaction((tx) async {
      final mySnap = await tx.get(myRef);
      final myBalance = (mySnap.data()?['coinBalance'] as num?)?.toInt() ?? 0;

      if (myBalance < coins) {
        throw Exception("Not enough coins");
      }

      final hostSnap = await tx.get(hostRef);
      final hostBalance =
          (hostSnap.data()?['coinBalance'] as num?)?.toInt() ?? 0;

      tx.update(myRef, {'coinBalance': myBalance - coins});
      tx.update(hostRef, {'coinBalance': hostBalance + coins});

      tx.set(_db.collection('giftTransactions').doc(), {
        'fromUid': _myUid,
        'toUid': hostUid,
        'coins': coins,
        'sentAt': FieldValue.serverTimestamp(),
      });
    });
  }
}
