import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'gemini_config.dart';
import 'ai_custom_facts.dart';

/// One prior turn in the conversation, used so the AI remembers context
/// instead of answering every message as if it's the first ("real" chat
/// behaviour, not a stateless one-shot Q&A box).
class GeminiTurn {
  final String role; // "user" or "model"
  final String text;
  const GeminiTurn(this.role, this.text);
}

class GeminiChatService {
  static const String _notConfigured =
      "AI assistant is not set up yet — add your Gemini API key in lib/gemini_config.dart";

  // If the AI hasn't replied at all within this long, something is wrong
  // (bad network / wrong key / Google API down) — fail with a clear
  // message instead of leaving the user staring at "Typing..." forever.
  static const Duration _timeout = Duration(seconds: 25);

  Uri _generateUrl() => Uri.parse(
        "https://generativelanguage.googleapis.com/v1beta/models/"
        "${GeminiConfig.model}:generateContent?key=${GeminiConfig.apiKey}",
      );

  Uri _streamUrl() => Uri.parse(
        "https://generativelanguage.googleapis.com/v1beta/models/"
        "${GeminiConfig.model}:streamGenerateContent?alt=sse&key=${GeminiConfig.apiKey}",
      );

  bool get _isConfigured =>
      GeminiConfig.apiKey.trim().isNotEmpty &&
      GeminiConfig.apiKey != "PASTE_YOUR_GEMINI_API_KEY_HERE";

  Map<String, dynamic> _body(String userMessage, List<GeminiTurn> history) {
    return {
      "systemInstruction": {
        "parts": [
          {"text": AiCustomFacts.systemPersona}
        ],
      },
      "contents": [
        for (final turn in history)
          {
            "role": turn.role,
            "parts": [
              {"text": turn.text}
            ],
          },
        {
          "role": "user",
          "parts": [
            {"text": userMessage}
          ],
        },
      ],
      "generationConfig": {
        "temperature": 0.7,
        "maxOutputTokens": GeminiConfig.maxOutputTokens,
      },
    };
  }

  /// FREE — plain text Q&A, no ad required. Waits for the full reply, then
  /// returns it in one go. Kept for callers that don't need streaming
  /// (e.g. the media-generation confirmation flow).
  Future<String> sendMessage(
    String userMessage, {
    List<GeminiTurn> history = const [],
  }) async {
    if (!_isConfigured) return _notConfigured;

    try {
      final response = await http
          .post(
            _generateUrl(),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode(_body(userMessage, history)),
          )
          .timeout(_timeout);

      if (response.statusCode == 200) {
        return _extractText(jsonDecode(response.body));
      }
      return _errorMessageFor(response.statusCode, response.body);
    } on TimeoutException {
      return "AI is taking too long to respond — check your internet connection and try again.";
    } catch (e) {
      return "AI request error: $e";
    }
  }

  /// FREE — real-time streaming reply: yields chunks of text as Gemini
  /// generates them, so the UI can show the answer appearing word-by-word
  /// (fast, "real" chat feel) instead of one long wait.
  Stream<String> streamMessage(
    String userMessage, {
    List<GeminiTurn> history = const [],
  }) async* {
    if (!_isConfigured) {
      yield _notConfigured;
      return;
    }

    final client = http.Client();
    try {
      final request = http.Request("POST", _streamUrl())
        ..headers["Content-Type"] = "application/json"
        ..body = jsonEncode(_body(userMessage, history));

      final streamedResponse = await client.send(request).timeout(_timeout);

      if (streamedResponse.statusCode != 200) {
        final body = await streamedResponse.stream.bytesToString();
        yield _errorMessageFor(streamedResponse.statusCode, body);
        return;
      }

      var buffer = '';
      var gotAnyText = false;

      final lines = streamedResponse.stream
          .transform(utf8.decoder)
          .timeout(_timeout, onTimeout: (sink) {
        sink.close();
      });

      await for (final chunk in lines) {
        buffer += chunk;
        // Server-Sent Events frames are separated by a blank line.
        final frames = buffer.split('\n\n');
        buffer = frames.removeLast(); // keep the possibly-incomplete tail
        for (final frame in frames) {
          final line = frame.trim();
          if (!line.startsWith('data:')) continue;
          final jsonStr = line.substring(5).trim();
          if (jsonStr.isEmpty) continue;
          try {
            final text = _extractDeltaText(jsonDecode(jsonStr));
            if (text != null && text.isNotEmpty) {
              gotAnyText = true;
              yield text;
            }
          } catch (_) {
            // Malformed/partial frame — ignore, the rest of the stream
            // still comes through fine.
          }
        }
      }

      if (!gotAnyText) {
        yield "Sorry, I couldn't generate a reply. Try rephrasing your message.";
      }
    } on TimeoutException {
      yield "AI is taking too long to respond — check your internet connection and try again.";
    } catch (e) {
      yield "AI request error: $e";
    } finally {
      client.close();
    }
  }

  String? _extractDeltaText(dynamic data) {
    final candidates = data["candidates"] as List?;
    if (candidates == null || candidates.isEmpty) return null;
    final parts = candidates[0]["content"]?["parts"] as List?;
    if (parts == null || parts.isEmpty) return null;
    return parts[0]["text"] as String?;
  }

  String _extractText(dynamic data) {
    final candidates = data["candidates"] as List?;
    if (candidates == null || candidates.isEmpty) {
      final blockReason = data["promptFeedback"]?["blockReason"];
      return blockReason != null
          ? "The AI couldn't answer that (blocked: $blockReason). Try rephrasing."
          : "Sorry, I couldn't generate a reply.";
    }
    final text = _extractDeltaText(data);
    return (text == null || text.trim().isEmpty)
        ? "Sorry, I couldn't generate a reply."
        : text;
  }

  String _errorMessageFor(int statusCode, String body) {
    switch (statusCode) {
      case 400:
        return "AI request was invalid — check that your Gemini API key in gemini_config.dart is correct.";
      case 403:
        return "AI request was rejected — the API key is invalid or not authorized for this model.";
      case 404:
        return "AI model \"${GeminiConfig.model}\" was not found — check the model name in gemini_config.dart.";
      case 429:
        return "AI is rate-limited right now (too many requests) — please wait a moment and try again.";
      case 500:
      case 503:
        return "The AI service is temporarily unavailable — please try again shortly.";
      default:
        return "AI request failed ($statusCode). Please try again.";
    }
  }

  /// PAID (gated by a rewarded ad in the UI layer — see
  /// ai_help_assistant_screen.dart). This function itself does not check
  /// for the ad; the screen only calls this after RewardedAdService reports
  /// the ad was watched to completion.
  ///
  /// This is a stub — plug in whichever image/video generation API you
  /// have access to (Gemini's image models, another provider, etc.) and
  /// return the resulting image/video URL or bytes.
  Future<String> generateMedia(String prompt) async {
    await Future.delayed(const Duration(seconds: 2)); // simulate generation
    return "Media generation not yet connected to a real model — wire your chosen image/video API inside generateMedia() in gemini_chat_service.dart.";
  }
}
