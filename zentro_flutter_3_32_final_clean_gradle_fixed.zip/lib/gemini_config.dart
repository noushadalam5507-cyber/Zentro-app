// ============================================================
// GEMINI AI CONFIGURATION
// ============================================================
// Get your API key from: https://aistudio.google.com/apikey
//
// PASTE YOUR GEMINI API KEY ON THE LINE BELOW (line 9)
// ============================================================

class GeminiConfig {
  static const String apiKey = "PASTE_YOUR_GEMINI_API_KEY_HERE"; // <-- line 9

  // "gemini-2.5-flash" is the current fast, generally-available model —
  // good balance of speed + reply quality for a real-time chat.
  // For even faster/cheaper (slightly shorter/simpler) replies, swap to
  // "gemini-2.5-flash-lite". Check https://ai.google.dev/gemini-api/docs/models
  // for the latest model list if you want to try a newer one later.
  static const String model = "gemini-2.5-flash";

  // Streaming makes replies appear word-by-word as they're generated
  // (like real ChatGPT/Gemini apps) instead of waiting for the full
  // answer — this is what makes the in-app AI chat feel fast.
  static const bool useStreaming = true;

  // Keeps replies quick and chat-sized instead of long essays.
  static const int maxOutputTokens = 1024;
}
