import 'package:flutter/material.dart';
import 'coin_wallet_service.dart';
import 'coin_store_screen.dart';

const Map<String, int> _giftOptions = {
  "🌹 Rose": 10,
  "🎉 Confetti": 50,
  "💎 Diamond": 200,
  "👑 Crown": 500,
};

/// Drop this button into a call screen's control row; it opens a bottom
/// sheet of gifts the viewer can send to [hostUid].
class GiftButton extends StatelessWidget {
  final String hostUid;
  const GiftButton({Key? key, required this.hostUid}) : super(key: key);

  void _openGiftSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF120826),
      builder: (context) => _GiftSheet(hostUid: hostUid),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _openGiftSheet(context),
      child: const CircleAvatar(
        radius: 28,
        backgroundColor: Colors.white24,
        child: Icon(Icons.card_giftcard, color: Colors.white),
      ),
    );
  }
}

class _GiftSheet extends StatelessWidget {
  final String hostUid;
  const _GiftSheet({required this.hostUid});

  Future<void> _sendGift(BuildContext context, String label, int coins) async {
    try {
      await CoinWalletService().sendGift(hostUid: hostUid, coins: coins);
      if (context.mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text("Sent $label!")));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text("Not enough coins"),
          action: SnackBarAction(
            label: "Buy coins",
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CoinStoreScreen()),
              );
            },
          ),
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Wrap(
        spacing: 16,
        runSpacing: 16,
        children: _giftOptions.entries.map((entry) {
          return GestureDetector(
            onTap: () => _sendGift(context, entry.key, entry.value),
            child: Column(
              children: [
                Text(entry.key, style: const TextStyle(fontSize: 32)),
                const SizedBox(height: 4),
                Text("${entry.value} coins",
                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
