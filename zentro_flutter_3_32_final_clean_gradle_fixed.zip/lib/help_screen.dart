import 'package:flutter/material.dart';

import 'ai_help_assistant_screen.dart';

/// Settings -> Help. Quick answers, the founder's name, and a shortcut to
/// the in-app Cloud AI assistant.
class HelpScreen extends StatelessWidget {
  const HelpScreen({Key? key}) : super(key: key);

  static const List<List<String>> _faqs = [
    [
      'How do I sign in?',
      'Use Truecaller, Google, or create an account with your name, '
          'email and password on the first screen.',
    ],
    [
      'How do I make a Reel or Story?',
      'After signing in, tap "Create Reel / Story" on the home screen and '
          'allow camera access when asked.',
    ],
    [
      'How do I start a video call?',
      'Tap "Start Video Call" on the home screen and allow camera and '
          'microphone access.',
    ],
    [
      'The camera shows a permission screen.',
      'Tap "Open Settings" and turn on Camera (and Microphone) for Zentro.',
    ],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07020D),
      appBar: AppBar(title: const Text('Help')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ---- Founder ----
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: const [
                  Icon(Icons.verified, color: Color(0xFFFF1493), size: 30),
                  SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Founder',
                            style: TextStyle(
                                color: Colors.white54, fontSize: 12)),
                        SizedBox(height: 2),
                        Text('Noushad Alam  (नौशाद आलम)',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            )),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // ---- Ask the AI ----
            ElevatedButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const AiHelpAssistantScreen()),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF1493),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              icon: const Icon(Icons.smart_toy),
              label: const Text('Ask Zentro Cloud AI'),
            ),

            const Padding(
              padding: EdgeInsets.fromLTRB(4, 24, 4, 8),
              child: Text('COMMON QUESTIONS',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  )),
            ),
            for (final faq in _faqs)
              Theme(
                data: Theme.of(context)
                    .copyWith(dividerColor: Colors.transparent),
                child: ExpansionTile(
                  iconColor: Colors.white70,
                  collapsedIconColor: Colors.white54,
                  title: Text(faq[0],
                      style: const TextStyle(color: Colors.white)),
                  childrenPadding:
                      const EdgeInsets.fromLTRB(16, 0, 16, 14),
                  expandedCrossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(faq[1],
                        style: const TextStyle(
                            color: Colors.white70, height: 1.4)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
