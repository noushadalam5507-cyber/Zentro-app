import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Shows a full-screen interstitial at major transitions (e.g. after a
/// call ends, or opening a popular profile). Interstitials are shown at
/// natural pause points, not mid-task, per AdMob policy.
class InterstitialAdService {
  static final InterstitialAdService _instance =
      InterstitialAdService._internal();
  factory InterstitialAdService() => _instance;
  InterstitialAdService._internal();

  InterstitialAd? _ad;
  bool _isLoading = false;
  DateTime? _lastShownAt;

  // Google's TEST interstitial ad unit ID. Replace with your own real
  // interstitial ad unit ID from https://apps.admob.com -> Ad units
  // (create a new "Interstitial" unit under app
  // ca-app-pub-9658260608635009~8417798607 — your banner and rewarded
  // units cannot be reused here, each ad format needs its own unit).
  static const String _adUnitId = 'ca-app-pub-3940256099942544/1033173712';

  // Don't show interstitials more often than this — protects the user
  // experience and keeps you within AdMob's policy on ad frequency.
  static const Duration _minGapBetweenAds = Duration(minutes: 2);

  void preload() {
    if (_isLoading || _ad != null) return;
    _isLoading = true;
    InterstitialAd.load(
      adUnitId: _adUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _ad = ad;
          _isLoading = false;
        },
        onAdFailedToLoad: (error) {
          _ad = null;
          _isLoading = false;
        },
      ),
    );
  }

  /// Call at a natural transition point (call ended, left a popular
  /// profile). Silently does nothing if no ad is ready or the minimum gap
  /// hasn't passed yet — never blocks the transition itself.
  void maybeShow() {
    final now = DateTime.now();
    if (_lastShownAt != null &&
        now.difference(_lastShownAt!) < _minGapBetweenAds) {
      return;
    }
    if (_ad == null) {
      preload();
      return;
    }

    final ad = _ad!;
    _ad = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        preload();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        preload();
      },
    );
    _lastShownAt = now;
    ad.show();
  }
}
