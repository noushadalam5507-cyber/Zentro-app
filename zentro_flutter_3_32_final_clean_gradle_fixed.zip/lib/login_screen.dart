import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'auth_service.dart';
import 'truecaller_auth_service.dart';

/// Sign-in / sign-up panel shown on the home screen while logged out.
///
/// Three ways in:
///  - Truecaller
///  - Google
///  - Email + password (with a "Create account" mode that asks for Full Name)
///
/// Whichever way the user comes in, [onSignedIn] is called with the Firebase
/// user; the home screen then registers them as a Main User in Firestore.
class LoginPanel extends StatefulWidget {
  final Future<void> Function(User user) onSignedIn;
  const LoginPanel({Key? key, required this.onSignedIn}) : super(key: key);

  @override
  State<LoginPanel> createState() => _LoginPanelState();
}

class _LoginPanelState extends State<LoginPanel> {
  static const Color _truecallerBlue = Color(0xFF0087FF);
  static const Color _accent = Color(0xFFFF1493);

  final _auth = AuthService();
  final _truecaller = TruecallerAuthService();

  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  bool _signUpMode = false;
  bool _hidePassword = true;
  bool _busy = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Runs one sign-in attempt with a shared busy flag + error handling.
  Future<void> _run(Future<User?> Function() attempt) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final user = await attempt();
      if (user != null) {
        await widget.onSignedIn(user);
      }
    } on TruecallerAuthException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast(AuthService.friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submitEmail() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    FocusScope.of(context).unfocus();
    await _run(() {
      if (_signUpMode) {
        return _auth.signUpWithEmail(
          name: _nameCtrl.text,
          email: _emailCtrl.text,
          password: _passCtrl.text,
        );
      }
      return _auth.signInWithEmail(
        email: _emailCtrl.text,
        password: _passCtrl.text,
      );
    });
  }

  InputDecoration _fieldDecoration(String label, IconData icon,
      {Widget? suffix}) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, size: 20),
      suffixIcon: suffix,
      filled: true,
      fillColor: Colors.white10,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _accent),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 360),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ---- Truecaller ----
          ElevatedButton.icon(
            onPressed: _busy ? null : () => _run(_truecaller.signIn),
            style: ElevatedButton.styleFrom(
              backgroundColor: _truecallerBlue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            icon: const Icon(Icons.verified_user),
            label: const Text('Sign in with Truecaller'),
          ),
          const SizedBox(height: 10),

          // ---- Google ----
          ElevatedButton.icon(
            onPressed: _busy ? null : () => _run(_auth.signInWithGoogle),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            icon: const Icon(Icons.login),
            label: const Text('Sign in with Google'),
          ),

          const Padding(
            padding: EdgeInsets.symmetric(vertical: 18),
            child: Row(
              children: [
                Expanded(child: Divider(color: Colors.white24)),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  child: Text('or use email',
                      style: TextStyle(color: Colors.white54, fontSize: 12)),
                ),
                Expanded(child: Divider(color: Colors.white24)),
              ],
            ),
          ),

          // ---- Email / password ----
          Form(
            key: _formKey,
            child: Column(
              children: [
                if (_signUpMode) ...[
                  TextFormField(
                    controller: _nameCtrl,
                    textCapitalization: TextCapitalization.words,
                    textInputAction: TextInputAction.next,
                    decoration:
                        _fieldDecoration('Full name', Icons.person_outline),
                    validator: (v) => (v == null || v.trim().length < 2)
                        ? 'Please enter your full name'
                        : null,
                  ),
                  const SizedBox(height: 12),
                ],
                TextFormField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  autocorrect: false,
                  decoration:
                      _fieldDecoration('Email (Gmail)', Icons.email_outlined),
                  validator: (v) {
                    final t = v?.trim() ?? '';
                    final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(t);
                    return ok ? null : 'Please enter a valid email';
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _passCtrl,
                  obscureText: _hidePassword,
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) => _submitEmail(),
                  decoration: _fieldDecoration(
                    'Password',
                    Icons.lock_outline,
                    suffix: IconButton(
                      icon: Icon(
                        _hidePassword ? Icons.visibility_off : Icons.visibility,
                        size: 20,
                      ),
                      onPressed: () =>
                          setState(() => _hidePassword = !_hidePassword),
                    ),
                  ),
                  validator: (v) => (v == null || v.length < 6)
                      ? 'Password must be at least 6 characters'
                      : null,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          ElevatedButton(
            onPressed: _busy ? null : _submitEmail,
            style: ElevatedButton.styleFrom(
              backgroundColor: _accent,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: _busy
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : Text(_signUpMode ? 'Create account' : 'Sign in'),
          ),

          TextButton(
            onPressed: _busy
                ? null
                : () => setState(() => _signUpMode = !_signUpMode),
            child: Text(
              _signUpMode
                  ? 'Already have an account? Sign in'
                  : 'New here? Create an account',
            ),
          ),
        ],
      ),
    );
  }
}
