import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'auth_service.dart';
import 'video_call_screen.dart';
import 'settings_screen.dart';
import 'social_service.dart';
import 'camera_screen.dart';
import 'login_screen.dart';
import 'app_settings_service.dart';
import 'usage_time_service.dart';
import 'studio_webview_screen.dart';
import 'ai_chat_screen.dart';

final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp();
  await MobileAds.instance.initialize();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF07020D),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  await AppSettingsService.load();
  runApp(const ZentroApp());
  UsageTimeService.instance.start(appNavigatorKey);
}

class ZentroApp extends StatelessWidget {
  const ZentroApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Instagrand',
      navigatorKey: appNavigatorKey,
      debugShowCheckedModeBanner: false,
      builder: (context, child) {
        return ValueListenableBuilder<double>(
          valueListenable: AppSettingsService.textScale,
          builder: (context, scale, _) => ValueListenableBuilder<bool>(
            valueListenable: AppSettingsService.boldText,
            builder: (context, bold, __) {
              final mq = MediaQuery.of(context);
              return MediaQuery(
                data: mq.copyWith(
                    textScaler: TextScaler.linear(scale), boldText: bold),
                child: child ?? const SizedBox.shrink(),
              );
            },
          ),
        );
      },
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF07020D),
        primaryColor: const Color(0xFFFF1493),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AuthService _authService = AuthService();
  User? _user;
  BannerAd? _bannerAd;
  StreamSubscription<User?>? _authSub;

  @override
  void initState() {
    super.initState();
    _user = _authService.currentUser;
    if (_user != null) {
      // Already signed in from a previous launch: make sure the profile
      // (and Main User type) exists. Failure here must never block the app.
      SocialService().ensureUserProfile().catchError((Object e) {
        // ignore: avoid_print
        print('ensureUserProfile error: $e');
      });
    }
    // If the user logs out from anywhere (e.g. Settings -> Log Out), bring
    // the login panel back instead of showing the old account.
    _authSub = FirebaseAuth.instance.authStateChanges().listen((u) {
      if (u == null && _user != null && mounted) {
        setState(() => _user = null);
      }
    });
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-9658260608635009/2583529714',
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) => setState(() {}),
        onAdFailedToLoad: (ad, error) => ad.dispose(),
      ),
    )..load();
  }

  /// Called by the login panel after ANY successful sign-in
  /// (Truecaller, Google, or email + password).
  Future<void> _handleSignedIn(User user) async {
    try {
      // Registers the account in Firestore as a Main User.
      await SocialService().ensureUserProfile();
    } catch (e) {
      // ignore: avoid_print
      print('ensureUserProfile error: $e');
    }
    if (!mounted) return;
    setState(() => _user = user);
  }

  Future<void> _handleSignOut() async {
    await _authService.signOut();
    setState(() => _user = null);
  }

  @override
  void dispose() {
    _authSub?.cancel();
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07020D),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 84,
                      height: 84,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            Color(0xFFFF6B00),
                            Color(0xFFFF1493),
                            Color(0xFFA855F7),
                            Color(0xFF00D2FF),
                          ],
                        ),
                      ),
                      child: const Icon(Icons.flash_on,
                          color: Colors.white, size: 48),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      "ZENTRO 4K STUDIO",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 3,
                      ),
                    ),
                    const SizedBox(height: 30),

                    if (_user == null)
                      LoginPanel(onSignedIn: _handleSignedIn)
                    else ...[
                      Text(
                        "Logged in as: ${_user!.displayName ?? _user!.email}",
                        style: const TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const VideoCallScreen(),
                            ),
                          );
                        },
                        icon: const Icon(Icons.videocam),
                        label: const Text("Start Video Call"),
                      ),
                const SizedBox(height: 12),
                      ElevatedButton.icon(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const CameraScreen(),
                            ),
                          );
                        },
                        icon: const Icon(Icons.camera_alt),
                        label: const Text("Create Reel / Story"),
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton.icon(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AiChatScreen(),
                          ),
                        ),
                        icon: const Icon(Icons.auto_awesome),
                        label: const Text("Zentro AI (Gemini)"),
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton.icon(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const StudioWebViewScreen(),
                          ),
                        ),
                        icon: const Icon(Icons.public),
                        label: const Text("Zentro Web Studio"),
                      ),
                      const SizedBox(height: 12),
                      TextButton.icon(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const SettingsScreen(),
                          ),
                        ),
                        icon: const Icon(Icons.settings),
                        label: const Text("Settings and Activity"),
                      ),
                      TextButton(
                        onPressed: _handleSignOut,
                        child: const Text("Sign out"),
                      ),
                    ],
                  ],
                  ),
                ),
              ),
            ),

            // AdMob banner pinned at the bottom
            if (_bannerAd != null)
              SizedBox(
                width: _bannerAd!.size.width.toDouble(),
                height: _bannerAd!.size.height.toDouble(),
                child: AdWidget(ad: _bannerAd!),
              ),
          ],
        ),
      ),
    );
  }
}
