import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

/// Configuration is injected at build time, so the API key is never written
/// into source control:
///
///   flutter run --dart-define=OPENROUTER_API_KEY=sk-or-v1-xxxx
///   flutter build apk --dart-define=OPENROUTER_API_KEY=sk-or-v1-xxxx \
///       --dart-define=OPENROUTER_MODEL=google/gemini-2.5-flash
class OpenRouterConfig {
  static const String endpoint =
      'https://openrouter.ai/api/v1/chat/completions';

  static const String apiKey = String.fromEnvironment(
    'OPENROUTER_API_KEY',
    defaultValue:
        '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',
  );

  /// Any vision-capable OpenRouter model id works here.
  static const String model = String.fromEnvironment(
    'OPENROUTER_MODEL',
    defaultValue: 'google/gemini-2.5-flash',
  );

  // Optional attribution headers shown on your OpenRouter dashboard.
  static const String appUrl = String.fromEnvironment(
    'OPENROUTER_APP_URL',
    defaultValue: 'https://instagrand-30a3f.firebaseapp.com',
  );
  static const String appTitle = String.fromEnvironment(
    'OPENROUTER_APP_TITLE',
    defaultValue: 'Zentro AI',
  );
}

class OpenRouterException implements Exception {
  final String message;
  final int? statusCode;
  OpenRouterException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

class OpenRouterService {
  OpenRouterService({
    http.Client? client,
    this.systemPrompt =
        'You are a helpful, friendly assistant inside a mobile app. '
            'Reply in the same language the user writes in. '
            'Keep answers clear and reasonably short.',
  }) : _client = client ?? http.Client();

  final http.Client _client;
  final String systemPrompt;

  /// Conversation memory (user + assistant turns), sent with every request.
  final List<Map<String, dynamic>> _history = <Map<String, dynamic>>[];

  static const int _maxHistoryMessages = 20;
  static const int _maxImageBytes = 8 * 1024 * 1024;

  void resetConversation() => _history.clear();

  void dispose() => _client.close();

  // ---------------------------------------------------------------- text

  Future<String> sendText(String prompt) {
    final text = prompt.trim();
    if (text.isEmpty) {
      throw OpenRouterException('Please type or say something first.');
    }
    return _complete(<String, dynamic>{'role': 'user', 'content': text});
  }

  // -------------------------------------------------------------- vision

  /// Reads [image], converts it to a Base64 data URL and sends it together
  /// with [prompt] in the OpenRouter `image_url` content format.
  Future<String> sendImage(File image, {String prompt = ''}) async {
    final Uint8List bytes = await image.readAsBytes();
    if (bytes.isEmpty) {
      throw OpenRouterException('The selected image is empty.');
    }
    if (bytes.length > _maxImageBytes) {
      throw OpenRouterException(
          'This image is too large. Please pick a photo under 8 MB.');
    }

    final String mime = _detectMime(bytes, image.path);
    final String dataUrl = 'data:$mime;base64,${base64Encode(bytes)}';
    final String question =
        prompt.trim().isEmpty ? 'Describe this photo in detail.' : prompt.trim();

    // Only the newest photo stays in memory as real image data; older ones
    // become text notes so requests do not grow bigger with every photo.
    _flattenOldImages();

    return _complete(<String, dynamic>{
      'role': 'user',
      'content': <Map<String, dynamic>>[
        <String, dynamic>{'type': 'text', 'text': question},
        <String, dynamic>{
          'type': 'image_url',
          'image_url': <String, dynamic>{'url': dataUrl},
        },
      ],
    });
  }

  // ------------------------------------------------------------ internals

  Future<String> _complete(Map<String, dynamic> userMessage) async {
    if (OpenRouterConfig.apiKey.isEmpty) {
      throw OpenRouterException(
          'OpenRouter API key is missing. Build the app with '
          '--dart-define=OPENROUTER_API_KEY=your_key');
    }

    _history.add(userMessage);
    try {
      final String body = jsonEncode(<String, dynamic>{
        'model': OpenRouterConfig.model,
        'messages': <Map<String, dynamic>>[
          <String, dynamic>{'role': 'system', 'content': systemPrompt},
          ..._history,
        ],
        'max_tokens': 1024,
        'temperature': 0.7,
      });

      final http.Response response = await _client
          .post(
            Uri.parse(OpenRouterConfig.endpoint),
            headers: <String, String>{
              'Authorization': 'Bearer ${OpenRouterConfig.apiKey}',
              'Content-Type': 'application/json',
              'HTTP-Referer': OpenRouterConfig.appUrl,
              'X-Title': OpenRouterConfig.appTitle,
            },
            body: body,
          )
          .timeout(const Duration(seconds: 60));

      final String reply = _parseReply(response);
      _history.add(<String, dynamic>{'role': 'assistant', 'content': reply});
      _trimHistory();
      return reply;
    } catch (e) {
      // A failed request must not leave a dangling user turn in memory.
      _history.remove(userMessage);
      if (e is OpenRouterException) rethrow;
      if (e is TimeoutException) {
        throw OpenRouterException(
            'The request timed out. Check your connection and try again.');
      }
      if (e is SocketException || e is http.ClientException) {
        throw OpenRouterException(
            'No internet connection. Please check your network.');
      }
      throw OpenRouterException('Unexpected error: $e');
    }
  }

  String _parseReply(http.Response response) {
    Map<String, dynamic>? json;
    try {
      final dynamic decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is Map<String, dynamic>) json = decoded;
    } catch (_) {
      json = null;
    }

    if (response.statusCode != 200) {
      throw OpenRouterException(
        _errorMessage(response.statusCode, json),
        statusCode: response.statusCode,
      );
    }
    if (json == null) {
      throw OpenRouterException('The server sent an unreadable response.');
    }
    // OpenRouter can return HTTP 200 with an error object in the body.
    if (json['error'] != null) {
      throw OpenRouterException(_errorMessage(200, json));
    }

    final dynamic choices = json['choices'];
    if (choices is! List || choices.isEmpty) {
      throw OpenRouterException('The model returned no answer. Try again.');
    }
    final dynamic first = choices.first;
    final dynamic message = first is Map ? first['message'] : null;
    final dynamic content = message is Map ? message['content'] : null;

    String text = '';
    if (content is String) {
      text = content;
    } else if (content is List) {
      text = content
          .whereType<Map>()
          .map((Map p) => p['text']?.toString() ?? '')
          .join();
    }
    text = text.trim();
    if (text.isEmpty) {
      throw OpenRouterException('The model returned an empty reply. Try again.');
    }
    return text;
  }

  String _errorMessage(int status, Map<String, dynamic>? json) {
    final dynamic err = json?['error'];
    final String? apiMessage = err is Map ? err['message']?.toString() : null;

    switch (status) {
      case 401:
        return 'Invalid OpenRouter API key.';
      case 402:
        return 'Not enough OpenRouter credits for this model.';
      case 403:
        return apiMessage ?? 'This request was blocked by moderation.';
      case 408:
        return 'The request timed out. Please try again.';
      case 429:
        return 'Rate limit reached. Please wait a moment and try again.';
      case 502:
      case 503:
        return 'The AI model is temporarily unavailable. Try again shortly.';
      default:
        return apiMessage ?? 'Request failed (HTTP $status).';
    }
  }

  void _trimHistory() {
    while (_history.length > _maxHistoryMessages) {
      _history.removeAt(0);
    }
    // History must start with a user turn.
    while (_history.isNotEmpty && _history.first['role'] != 'user') {
      _history.removeAt(0);
    }
  }

  void _flattenOldImages() {
    for (int i = 0; i < _history.length; i++) {
      final Map<String, dynamic> m = _history[i];
      final dynamic content = m['content'];
      if (content is List) {
        final String text = content
            .whereType<Map>()
            .where((Map p) => p['type'] == 'text')
            .map((Map p) => p['text']?.toString() ?? '')
            .join(' ');
        _history[i] = <String, dynamic>{
          'role': m['role'],
          'content': '[The user shared a photo earlier] $text',
        };
      }
    }
  }

  String _detectMime(Uint8List b, String path) {
    if (b.length >= 3 && b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF) {
      return 'image/jpeg';
    }
    if (b.length >= 4 &&
        b[0] == 0x89 &&
        b[1] == 0x50 &&
        b[2] == 0x4E &&
        b[3] == 0x47) {
      return 'image/png';
    }
    if (b.length >= 12 &&
        b[0] == 0x52 &&
        b[1] == 0x49 &&
        b[2] == 0x46 &&
        b[3] == 0x46 &&
        b[8] == 0x57 &&
        b[9] == 0x45 &&
        b[10] == 0x42 &&
        b[11] == 0x50) {
      return 'image/webp';
    }
    if (b.length >= 4 &&
        b[0] == 0x47 &&
        b[1] == 0x49 &&
        b[2] == 0x46 &&
        b[3] == 0x38) {
      return 'image/gif';
    }
    final String p = path.toLowerCase();
    if (p.endsWith('.png')) return 'image/png';
    if (p.endsWith('.webp')) return 'image/webp';
    if (p.endsWith('.heic')) return 'image/heic';
    if (p.endsWith('.heif')) return 'image/heif';
    return 'image/jpeg';
  }
}
