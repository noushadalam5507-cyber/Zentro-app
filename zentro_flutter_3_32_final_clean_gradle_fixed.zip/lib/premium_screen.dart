import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'razorpay_config.dart';
import 'subscription_service.dart';

/// Purchase flow (all payment VERIFICATION happens server-side):
/// 1. App calls your Cloud Function (createOrderEndpoint) to create a
///    Razorpay order for this user.
/// 2. App opens the Razorpay checkout UI with that order ID.
/// 3. On success, Razorpay gives the app a payment ID + signature.
/// 4. App does NOT set isPremium itself. Your Cloud Function's Razorpay
///    webhook independently verifies the payment signature server-side and
///    is the only thing that writes isPremium/premiumUntil to Firestore.
/// 5. This screen just listens to Firestore (via SubscriptionService) and
///    updates once the webhook has done its job (usually a few seconds).
class PremiumScreen extends StatefulWidget {
  const PremiumScreen({Key? key}) : super(key: key);

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  late final Razorpay _razorpay;
  bool _processing = false;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _onPaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _onPaymentError);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  Future<void> _startCheckout() async {
    if (RazorpayConfig.keyId == "PASTE_YOUR_RAZORPAY_KEY_ID_HERE" ||
        RazorpayConfig.createOrderEndpoint ==
            "PASTE_YOUR_CLOUD_FUNCTION_URL_HERE") {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text(
            "Razorpay isn't configured yet — set keyId and createOrderEndpoint in razorpay_config.dart, and deploy the Cloud Function (see /backend)."),
      ));
      return;
    }

    setState(() => _processing = true);
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final response = await http.post(
        Uri.parse(RazorpayConfig.createOrderEndpoint),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "uid": uid,
          "amount": RazorpayConfig.monthlyPremiumPricePaise,
          "currency": RazorpayConfig.currency,
        }),
      );
      final order = jsonDecode(response.body);
      final orderId = order['orderId'];

      final options = {
        'key': RazorpayConfig.keyId,
        'amount': RazorpayConfig.monthlyPremiumPricePaise,
        'currency': RazorpayConfig.currency,
        'name': 'Instagrand Premium',
        'description': 'Monthly Premium Subscription',
        'order_id': orderId,
        'notes': {'uid': uid},
      };
      _razorpay.open(options);
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Could not start checkout: $e")));
    } finally {
      setState(() => _processing = false);
    }
  }

  void _onPaymentSuccess(PaymentSuccessResponse response) {
    // Do NOT set isPremium here. The Cloud Function webhook verifies the
    // payment server-side and updates Firestore on its own. This is just
    // a friendly message while we wait for that to land.
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text(
          "Payment received — activating Premium (may take a few seconds)..."),
    ));
  }

  void _onPaymentError(PaymentFailureResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text("Payment failed: ${response.message}"),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Premium Subscription")),
      body: StreamBuilder<bool>(
        stream: SubscriptionService().isPremiumStream(),
        builder: (context, snapshot) {
          final isPremium = snapshot.data ?? false;
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    isPremium ? Icons.verified : Icons.star_border,
                    color: isPremium ? Colors.blueAccent : Colors.white54,
                    size: 64,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    isPremium
                        ? "You're a Premium member"
                        : "Go Premium",
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Blue Badge + premium camera filters",
                    style: TextStyle(color: Colors.white54),
                  ),
                  const SizedBox(height: 24),
                  if (!isPremium)
                    ElevatedButton(
                      onPressed: _processing ? null : _startCheckout,
                      child: _processing
                          ? const CircularProgressIndicator()
                          : const Text("Subscribe — ₹149/month"),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
