import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Firestore structure added by this service:
///
/// users/{uid}                     -> adds field: isPrivate (bool)
/// users/{uid}/blocked/{blockedUid} -> { since: Timestamp }
///
/// Privacy is enforced by the read/query logic below (and should also be
/// mirrored in your Firestore Security Rules — client-side checks alone are
/// not real security, only real security rules are).
class PrivacyService {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  String get _myUid => _auth.currentUser!.uid;

  // ---------------- ACCOUNT PRIVACY (Public / Private) ----------------

  Future<void> setPrivate(bool isPrivate) async {
    await _db.collection('users').doc(_myUid).set(
      {'isPrivate': isPrivate},
      SetOptions(merge: true),
    );
  }

  Stream<bool> isPrivateStream(String uid) {
    return _db.collection('users').doc(uid).snapshots().map(
          (doc) => doc.data()?['isPrivate'] == true,
        );
  }

  /// True if `viewerUid` is allowed to see `targetUid`'s content:
  /// always true for public accounts and for the owner, only true for a
  /// private account if the viewer already follows the target.
  Future<bool> canView(String viewerUid, String targetUid) async {
    if (viewerUid == targetUid) return true;

    final targetDoc = await _db.collection('users').doc(targetUid).get();
    final isPrivate = targetDoc.data()?['isPrivate'] == true;
    if (!isPrivate) return true;

    final followDoc = await _db
        .collection('users')
        .doc(targetUid)
        .collection('followers')
        .doc(viewerUid)
        .get();
    return followDoc.exists;
  }

  // ---------------- BLOCKED USERS ----------------

  Future<void> blockUser(String otherUid) async {
    final batch = _db.batch();
    batch.set(
      _db.collection('users').doc(_myUid).collection('blocked').doc(otherUid),
      {'since': FieldValue.serverTimestamp()},
    );
    // Blocking also removes any existing follow relationship both ways
    batch.delete(_db
        .collection('users')
        .doc(otherUid)
        .collection('followers')
        .doc(_myUid));
    batch.delete(_db
        .collection('users')
        .doc(_myUid)
        .collection('following')
        .doc(otherUid));
    batch.delete(_db
        .collection('users')
        .doc(_myUid)
        .collection('followers')
        .doc(otherUid));
    batch.delete(_db
        .collection('users')
        .doc(otherUid)
        .collection('following')
        .doc(_myUid));
    await batch.commit();
  }

  Future<void> unblockUser(String otherUid) async {
    await _db
        .collection('users')
        .doc(_myUid)
        .collection('blocked')
        .doc(otherUid)
        .delete();
  }

  Stream<bool> isBlockedByMe(String otherUid) {
    return _db
        .collection('users')
        .doc(_myUid)
        .collection('blocked')
        .doc(otherUid)
        .snapshots()
        .map((doc) => doc.exists);
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> blockedUsersStream() {
    return _db
        .collection('users')
        .doc(_myUid)
        .collection('blocked')
        .snapshots();
  }

  /// Call before allowing a follow, message, or call — prevents a blocked
  /// user from interacting even if they still have an old UI open.
  Future<bool> isInteractionBlocked(String otherUid) async {
    final iBlockedThem = await _db
        .collection('users')
        .doc(_myUid)
        .collection('blocked')
        .doc(otherUid)
        .get();
    final theyBlockedMe = await _db
        .collection('users')
        .doc(otherUid)
        .collection('blocked')
        .doc(_myUid)
        .get();
    return iBlockedThem.exists || theyBlockedMe.exists;
  }

  // ---------------- MESSAGE CONTROLS ----------------

  /// 'everyone' | 'following' (only people I follow) | 'nobody'
  Future<void> setMessagePolicy(String policy) async {
    await _db.collection('users').doc(_myUid).set(
      {'messagePolicy': policy},
      SetOptions(merge: true),
    );
  }

  /// Temporarily treats the account as "following only" for [duration].
  /// Pass null to switch it off.
  Future<void> limitInteractionsFor(Duration? duration) async {
    await _db.collection('users').doc(_myUid).set(
      {
        'limitUntil': duration == null
            ? FieldValue.delete()
            : Timestamp.fromDate(DateTime.now().add(duration)),
      },
      SetOptions(merge: true),
    );
  }

  /// Returns a human-readable reason if I may NOT message [otherUid],
  /// or null if I can. The same rules are enforced server-side in
  /// backend/firestore.rules, so this is only for a friendly error.
  Future<String?> messageBlockReason(String otherUid) async {
    if (await isInteractionBlocked(otherUid)) {
      return "आप इस अकाउंट को मैसेज नहीं कर सकते।";
    }
    final doc = await _db.collection('users').doc(otherUid).get();
    final d = doc.data() ?? <String, dynamic>{};
    final policy = (d['messagePolicy'] as String?) ?? 'everyone';
    final until = (d['limitUntil'] as Timestamp?)?.toDate();
    final limited = until != null && until.isAfter(DateTime.now());

    if (policy == 'nobody') {
      return "यह अकाउंट अभी मैसेज नहीं ले रहा।";
    }
    if (policy == 'following' || limited) {
      // "they follow me" == my followers/{them} exists (publicly readable)
      final theyFollowMe = await _db
          .collection('users')
          .doc(_myUid)
          .collection('followers')
          .doc(otherUid)
          .get();
      if (!theyFollowMe.exists) {
        return 'यह अकाउंट सिर्फ़ उन्हीं से मैसेज लेता है जिन्हें यह फॉलो करता है।';
      }
    }
    return null;
  }
}
