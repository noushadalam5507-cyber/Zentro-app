import 'package:flutter/material.dart';
import 'social_service.dart';
import 'subscription_service.dart';
import 'privacy_service.dart';
import 'interstitial_ad_service.dart';
import 'chat_screen.dart';

// A profile counts as "popular" for ad-frequency purposes above this many
// real followers. Purely a monetization threshold — has no effect on the
// follower count shown, which always comes straight from Firestore.
const int _popularFollowerThreshold = 1000;

// The one account that gets a Founder/Admin badge. This ONLY toggles a
// visual badge — it never changes the follower count shown anywhere, which
// always comes straight from the real Firestore `followers` subcollection
// (see SocialService.followerCount). We deliberately do not fabricate or
// inflate follower numbers for any account: real users would be misled
// into thinking that count is organic.
const String _founderEmail = 'noushadalam5507@gmail.com';

class ProfileScreen extends StatefulWidget {
  final String uid;
  final String displayName;

  const ProfileScreen({
    Key? key,
    required this.uid,
    required this.displayName,
  }) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final SocialService _social = SocialService();
  bool _adTriggeredForThisProfile = false;

  void _maybeShowInterstitial(int followerCount) {
    if (_adTriggeredForThisProfile) return;
    if (followerCount >= _popularFollowerThreshold) {
      _adTriggeredForThisProfile = true;
      // Slight delay so the ad doesn't fight with the profile's own
      // first-frame render.
      Future.delayed(const Duration(milliseconds: 400), () {
        InterstitialAdService().maybeShow();
      });
    }
  }

  @override
  void initState() {
    super.initState();
    InterstitialAdService().preload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.displayName)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(widget.displayName,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(width: 6),
                        StreamBuilder<String?>(
                          stream: _social.emailStream(widget.uid),
                          builder: (context, snapshot) {
                            final email = snapshot.data?.toLowerCase();
                            if (email != _founderEmail) {
                              return const SizedBox.shrink();
                            }
                            return const Tooltip(
                              message: 'Founder & Admin',
                              child: Icon(Icons.verified,
                                  color: Color(0xFFFFD700), size: 18),
                            );
                          },
                        ),
                        const SizedBox(width: 4),
                        StreamBuilder<bool>(
                          stream: SubscriptionService()
                              .isPremiumStream(widget.uid),
                          builder: (context, snapshot) {
                            if (snapshot.data != true) {
                              return const SizedBox.shrink();
                            }
                            return const Icon(Icons.verified,
                                color: Colors.blueAccent, size: 18);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    StreamBuilder<int>(
                      stream: _social.followerCount(widget.uid),
                      builder: (context, snapshot) {
                        final count = snapshot.data ?? 0;
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          _maybeShowInterstitial(count);
                        });
                        return Text(
                          "$count followers",
                          style: const TextStyle(color: Colors.white70),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          StreamBuilder<bool>(
            stream: PrivacyService().isPrivateStream(widget.uid),
            builder: (context, snapshot) {
              final isPrivate = snapshot.data ?? false;
              return Row(
                children: [
                  Expanded(
                    child: StreamBuilder<bool>(
                      stream: _social.isFollowing(widget.uid),
                      builder: (context, followSnap) {
                        final following = followSnap.data ?? false;
                        return ElevatedButton(
                          onPressed: () => following
                              ? _social.unfollowUser(widget.uid)
                              : _social.followUser(widget.uid),
                          child: Text(following ? "Unfollow" : "Follow"),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: isPrivate
                          ? null // real private-account gate — no message access unless followed
                          : () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    otherUid: widget.uid,
                                    otherDisplayName: widget.displayName,
                                  ),
                                ),
                              ),
                      child: Text(isPrivate ? "Private account" : "Message"),
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
