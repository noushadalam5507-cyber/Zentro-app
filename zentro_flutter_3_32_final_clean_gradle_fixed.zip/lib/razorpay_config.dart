// ============================================================
// RAZORPAY CONFIGURATION
// ============================================================
// Get your KEY ID (public, safe for client) from:
// https://dashboard.razorpay.com -> Settings -> API Keys
//
// NEVER put your Razorpay KEY SECRET in this app — it must live only on
// your backend (the Cloud Function), never in client code, or anyone who
// decompiles the APK can use it to create fraudulent charges.
// ============================================================

class RazorpayConfig {
  static const String keyId = "PASTE_YOUR_RAZORPAY_KEY_ID_HERE"; // <-- line 11

  // Your deployed Cloud Function URL that creates an order server-side.
  // e.g. https://us-central1-instagrand-30a3f.cloudfunctions.net/createOrder
  static const String createOrderEndpoint =
      "PASTE_YOUR_CLOUD_FUNCTION_URL_HERE";

  // Subscription plan price, in the smallest currency unit (paise for INR).
  static const int monthlyPremiumPricePaise = 14900; // ₹149/month
  static const String currency = "INR";
}
