import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Gates "AI Photo/Video Generation" behind a Rewarded Video Ad.
/// Text Q&A (GeminiChatService) is NOT gated by this — only media
/// generation is, per the free-vs-paid split.
class RewardedAdService {
  RewardedAd? _rewardedAd;
  bool _isLoading = false;

  // Google's TEST rewarded ad unit ID. Replace with your own real rewarded
  // ad unit ID from https://apps.admob.com -> Ad units before publishing.
  // (Your banner unit ca-app-pub-9658260608635009/2583529714 is a BANNER
  // unit and cannot be reused here — a rewarded unit must be created
  // separately in the AdMob console under the same app ID
  // ca-app-pub-9658260608635009~8417798607.)
  static const String _adUnitId = 'ca-app-pub-3940256099942544/5224354917';

  void preload() {
    if (_isLoading || _rewardedAd != null) return;
    _isLoading = true;
    RewardedAd.load(
      adUnitId: _adUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _isLoading = false;
        },
        onAdFailedToLoad: (error) {
          _rewardedAd = null;
          _isLoading = false;
        },
      ),
    );
  }

  /// Shows the rewarded ad and calls [onEarned] ONLY if the user watches it
  /// to completion. [onNoAdAvailable] fires if no ad could be loaded (e.g.
  /// no internet) — never falls through to running the paid action for
  /// free.
  Future<void> showAndRun({
    required Future<void> Function() onEarned,
    required VoidCallback onNoAdAvailable,
  }) async {
    if (_rewardedAd == null) {
      onNoAdAvailable();
      preload(); // try to have one ready for next time
      return;
    }

    final ad = _rewardedAd!;
    _rewardedAd = null; // each RewardedAd instance is single-use

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        preload();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        preload();
      },
    );

    bool earnedReward = false;

    await ad.show(
      onUserEarnedReward: (ad, reward) {
        earnedReward = true;
      },
    );

    if (earnedReward) {
      await onEarned();
    }
  }
}
