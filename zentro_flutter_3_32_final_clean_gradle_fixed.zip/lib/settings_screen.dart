import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'auth_service.dart';
import 'ai_help_assistant_screen.dart';
import 'privacy_service.dart';
import 'blocked_users_screen.dart';
import 'premium_screen.dart';
import 'coin_store_screen.dart';
import 'app_settings_service.dart';
import 'help_screen.dart';
import 'about_screen.dart';
import 'settings_screens.dart';

/// "सेटिंग्स और गतिविधि". Every entry opens a screen that really works:
/// nothing here is a placeholder. (Instagram items that depend on
/// posts/stories/comments are intentionally absent because this app has no
/// such features yet.)
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final PrivacyService _privacy = PrivacyService();
  final String _myUid = FirebaseAuth.instance.currentUser!.uid;
  final TextEditingController _search = TextEditingController();
  bool _voiceNavEnabled = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    AppSettingsService.isVoiceNavEnabled().then((value) {
      if (mounted) setState(() => _voiceNavEnabled = value);
    });
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _open(Widget screen) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => screen));

  @override
  Widget build(BuildContext context) {
    final q = _query.trim().toLowerCase();
    bool show(String label) => q.isEmpty || label.toLowerCase().contains(q);

    final sections = <_Section>[
      _Section("आपका अकाउंट", [
        _Item(Icons.account_circle_outlined, "अकाउंट स्टेटस",
            () => _open(const AccountStatusScreen())),
        _Item(Icons.security, "अकाउंट और सुरक्षा",
            () => _open(const AccountSecurityScreen())),
      ]),
      _Section("आप ऐप कैसे इस्तेमाल करते हो", [
        _Item(Icons.show_chart, "आपकी गतिविधि और समय प्रबंधन",
            () => _open(const TimeManagementScreen())),
      ]),
      _Section("आपका कंटेंट कौन देख सकता है", [
        _Item(Icons.block, "ब्लॉक किए गए", () => _open(const BlockedUsersScreen()),
            countStream: FirebaseFirestore.instance
                .collection('users')
                .doc(_myUid)
                .collection('blocked')
                .snapshots()
                .map((s) => s.docs.length)),
      ]),
      _Section("दूसरे आपसे कैसे जुड़ सकते हैं", [
        _Item(Icons.send_outlined, "मैसेज और बातचीत सीमित करना",
            () => _open(const MessageControlsScreen())),
        _Item(Icons.text_fields, "छिपे शब्द",
            () => _open(const HiddenWordsScreen())),
      ]),
      _Section("आपका ऐप और मीडिया", [
        _Item(Icons.smartphone, "डिवाइस परमिशन",
            () => _open(const DevicePermissionsScreen())),
        _Item(Icons.accessibility_new, "एक्सेसिबिलिटी",
            () => _open(const AccessibilityScreen())),
        _Item(Icons.signal_cellular_alt, "डेटा उपयोग और मीडिया क्वालिटी",
            () => _open(const DataUsageScreen())),
      ]),
      _Section("सब्सक्रिप्शन और पेमेंट", [
        _Item(Icons.verified_outlined, "प्रीमियम (ब्लू बैज)",
            () => _open(const PremiumScreen())),
        _Item(Icons.monetization_on_outlined, "कॉइन स्टोर",
            () => _open(const CoinStoreScreen())),
        _Item(Icons.receipt_long_outlined, "ऑर्डर और पेमेंट",
            () => _open(const OrdersPaymentsScreen())),
      ]),
      _Section("जानकारी और सपोर्ट", [
        _Item(Icons.smart_toy_outlined, "क्लाउड AI चैट",
            () => _open(const AiHelpAssistantScreen())),
        _Item(Icons.help_outline, "मदद", () => _open(const HelpScreen())),
        _Item(Icons.info_outline, "ऐप के बारे में", () => _open(const AboutScreen())),
      ]),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("सेटिंग्स और गतिविधि")),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              controller: _search,
              style: const TextStyle(color: Colors.white),
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: "खोजो",
                hintStyle: const TextStyle(color: Colors.white54),
                prefixIcon: const Icon(Icons.search, color: Colors.white54),
                filled: true,
                fillColor: Colors.white10,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),

          if (show("अकाउंट प्राइवेसी") || show("प्राइवेट अकाउंट")) ...[
            _sectionHeader("अकाउंट प्राइवेसी"),
            StreamBuilder<bool>(
              stream: _privacy.isPrivateStream(_myUid),
              builder: (context, snapshot) {
                final isPrivate = snapshot.data ?? false;
                return SwitchListTile(
                  secondary:
                      const Icon(Icons.lock_outline, color: Colors.white70),
                  title: const Text("प्राइवेट अकाउंट",
                      style: TextStyle(color: Colors.white)),
                  subtitle: Text(
                    isPrivate
                        ? "सिर्फ़ आपके मंज़ूर किए फॉलोवर्स आपका कंटेंट देख सकते हैं"
                        : "पब्लिक: कोई भी आपका कंटेंट देख सकता है",
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                  value: isPrivate,
                  onChanged: (value) => _privacy.setPrivate(value),
                );
              },
            ),
          ],
          if (show("वॉइस") || show("रील")) ...[
            _sectionHeader("रील्स"),
            SwitchListTile(
              secondary: const Icon(Icons.mic, color: Colors.white70),
              title: const Text("आवाज़ से रील नेविगेशन",
                  style: TextStyle(color: Colors.white)),
              subtitle: const Text(
                "रील्स देखते समय \"next\"/\"down\" या \"back\"/\"up\" बोलो। "
                "हाथ से स्वाइप दोनों हालत में चलता रहेगा।",
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
              value: _voiceNavEnabled,
              onChanged: (value) async {
                await AppSettingsService.setVoiceNavEnabled(value);
                setState(() => _voiceNavEnabled = value);
              },
            ),
          ],

          for (final s in sections)
            if (s.items.any((i) => show(i.label))) ...[
              _sectionHeader(s.title),
              for (final i in s.items)
                if (show(i.label)) _tile(i),
            ],

          if (show("लॉग आउट") || show("लॉगिन")) ...[
            _sectionHeader("लॉगिन"),
            ListTile(
              title: const Text("लॉग आउट",
                  style: TextStyle(color: Colors.redAccent, fontSize: 16)),
              onTap: () async {
                await AuthService().signOut();
                if (context.mounted) {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                }
              },
            ),
          ],
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
        child: Text(
          title,
          style: const TextStyle(
            color: Colors.white54,
            fontSize: 13,
            fontWeight: FontWeight.bold,
          ),
        ),
      );

  Widget _tile(_Item item) => ListTile(
        leading: Icon(item.icon, color: Colors.white70),
        title: Text(item.label, style: const TextStyle(color: Colors.white)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (item.countStream != null)
              StreamBuilder<int>(
                stream: item.countStream,
                builder: (c, s) => Text('${s.data ?? 0}',
                    style: const TextStyle(color: Colors.white54, fontSize: 13)),
              ),
            const Icon(Icons.chevron_right, color: Colors.white30),
          ],
        ),
        onTap: item.onTap,
      );
}

class _Section {
  final String title;
  final List<_Item> items;
  _Section(this.title, this.items);
}

class _Item {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Stream<int>? countStream;
  _Item(this.icon, this.label, this.onTap, {this.countStream});
}
