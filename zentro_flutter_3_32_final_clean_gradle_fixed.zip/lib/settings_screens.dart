import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:permission_handler/permission_handler.dart';
import 'app_settings_service.dart';
import 'usage_time_service.dart';
import 'privacy_service.dart';
import 'coin_wallet_service.dart';
import 'subscription_service.dart';
import 'auth_service.dart';

const Color _pink = Color(0xFFFF1493);

Widget _hdr(String t) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
      child: Text(t,
          style: const TextStyle(
              color: Colors.white54, fontSize: 13, fontWeight: FontWeight.bold)),
    );

Widget _note(String t) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Text(t, style: const TextStyle(color: Colors.white54, fontSize: 12)),
    );

Widget _choice(String title, String? sub, bool selected, VoidCallback onTap) =>
    ListTile(
      title: Text(title, style: const TextStyle(color: Colors.white)),
      subtitle: sub == null
          ? null
          : Text(sub, style: const TextStyle(color: Colors.white54, fontSize: 12)),
      trailing: selected ? const Icon(Icons.check_circle, color: _pink) : null,
      onTap: onTap,
    );

String _fmt(int seconds) {
  final h = seconds ~/ 3600;
  final m = (seconds % 3600) ~/ 60;
  if (h > 0) return '${h} घंटे ${m} मिनट';
  if (m > 0) return '${m} मिनट';
  return '${seconds} सेकंड';
}

// ======================================================================
// DEVICE PERMISSIONS  (real status + real request / open system settings)
// ======================================================================
class DevicePermissionsScreen extends StatefulWidget {
  const DevicePermissionsScreen({Key? key}) : super(key: key);
  @override
  State<DevicePermissionsScreen> createState() => _DevicePermissionsState();
}

class _DevicePermissionsState extends State<DevicePermissionsScreen>
    with WidgetsBindingObserver {
  final Map<Permission, PermissionStatus> _status = {};
  final List<_Perm> _perms = const [
    _Perm(Permission.camera, 'कैमरा', 'वीडियो कॉल और रील / स्टोरी बनाने के लिए',
        Icons.photo_camera_outlined),
    _Perm(Permission.microphone, 'माइक्रोफोन',
        'कॉल, वीडियो रिकॉर्डिंग और वॉइस नेविगेशन के लिए', Icons.mic_none),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    for (final p in _perms) {
      _status[p.permission] = await p.permission.status;
    }
    if (mounted) setState(() {});
  }

  Future<void> _tap(_Perm p) async {
    final s = _status[p.permission];
    if (s != null && s.isGranted) {
      await openAppSettings(); // can only be revoked from system settings
    } else if (s != null && (s.isPermanentlyDenied || s.isRestricted)) {
      await openAppSettings();
    } else {
      await p.permission.request();
    }
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('डिवाइस परमिशन')),
      body: ListView(
        children: [
          for (final p in _perms)
            ListTile(
              leading: Icon(p.icon, color: Colors.white70),
              title: Text(p.label, style: const TextStyle(color: Colors.white)),
              subtitle: Text(p.desc,
                  style: const TextStyle(color: Colors.white54, fontSize: 12)),
              trailing: Text(
                _label(_status[p.permission]),
                style: TextStyle(
                    color: (_status[p.permission]?.isGranted ?? false)
                        ? Colors.greenAccent
                        : Colors.orangeAccent),
              ),
              onTap: () => _tap(p),
            ),
          const SizedBox(height: 8),
          ListTile(
            leading: const Icon(Icons.settings_outlined, color: Colors.white70),
            title: const Text('सिस्टम ऐप सेटिंग खोलो',
                style: TextStyle(color: Colors.white)),
            onTap: () => openAppSettings(),
          ),
          _note('परमिशन देने के लिए उस पर टैप करो। एक बार देने के बाद Android में उसे '
              'सिर्फ़ सिस्टम सेटिंग से बंद किया जा सकता है।'),
        ],
      ),
    );
  }

  String _label(PermissionStatus? s) {
    if (s == null) return '...';
    if (s.isGranted) return 'अनुमति है';
    if (s.isPermanentlyDenied) return 'ब्लॉक है';
    if (s.isLimited) return 'सीमित';
    return 'अनुमति नहीं है';
  }
}

class _Perm {
  final Permission permission;
  final String label;
  final String desc;
  final IconData icon;
  const _Perm(this.permission, this.label, this.desc, this.icon);
}

// ======================================================================
// MESSAGE CONTROLS + LIMIT INTERACTIONS (enforced in firestore.rules too)
// ======================================================================
class MessageControlsScreen extends StatelessWidget {
  const MessageControlsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final privacy = PrivacyService();
    return Scaffold(
      appBar: AppBar(title: const Text('मैसेज और बातचीत')),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream:
            FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snap) {
          final d = snap.data?.data() ?? <String, dynamic>{};
          final policy = (d['messagePolicy'] as String?) ?? 'everyone';
          final until = (d['limitUntil'] as Timestamp?)?.toDate();
          final limited = until != null && until.isAfter(DateTime.now());
          return ListView(
            children: [
              _hdr('आपको कौन मैसेज कर सकता है'),
              _choice('सब लोग', null, policy == 'everyone',
                  () => privacy.setMessagePolicy('everyone')),
              _choice('सिर्फ़ जिन्हें आप फॉलो करते हो', null, policy == 'following',
                  () => privacy.setMessagePolicy('following')),
              _choice('कोई नहीं', null, policy == 'nobody',
                  () => privacy.setMessagePolicy('nobody')),
              _hdr('बातचीत सीमित करो'),
              _note(limited
                  ? '${until!.toLocal().toString().substring(0, 16)} तक चालू है। '
                      'तब तक सिर्फ़ वे लोग आपको मैसेज कर सकते हैं जिन्हें आप फॉलो करते हो।'
                  : 'कुछ समय के लिए सिर्फ़ उन्हीं से मैसेज आने दो जिन्हें आप फॉलो करते हो, '
                      'जैसे स्पैम या परेशान करने वाले मैसेज बढ़ने पर।'),
              _choice('बंद', null, !limited, () => privacy.limitInteractionsFor(null)),
              _choice('24 घंटे के लिए', null, false,
                  () => privacy.limitInteractionsFor(const Duration(hours: 24))),
              _choice('3 दिन के लिए', null, false,
                  () => privacy.limitInteractionsFor(const Duration(days: 3))),
              _choice('7 दिन के लिए', null, false,
                  () => privacy.limitInteractionsFor(const Duration(days: 7))),
              _note('ब्लॉक किए गए लोग आपको कभी मैसेज नहीं कर सकते, चाहे ये '
                  'सेटिंग्स कुछ भी हों।'),
            ],
          );
        },
      ),
    );
  }
}

// ======================================================================
// HIDDEN WORDS (hides matching incoming chat messages until tapped)
// ======================================================================
class HiddenWordsScreen extends StatefulWidget {
  const HiddenWordsScreen({Key? key}) : super(key: key);
  @override
  State<HiddenWordsScreen> createState() => _HiddenWordsState();
}

class _HiddenWordsState extends State<HiddenWordsScreen> {
  final TextEditingController _c = TextEditingController();
  List<String> _words = <String>[];
  bool _on = true;

  @override
  void initState() {
    super.initState();
    AppSettingsService.getHiddenWords().then((w) {
      if (mounted) setState(() => _words = w);
    });
    AppSettingsService.isHiddenWordsOn().then((v) {
      if (mounted) setState(() => _on = v);
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final w = _c.text.trim().toLowerCase();
    if (w.isEmpty || _words.contains(w)) return;
    final next = [..._words, w];
    await AppSettingsService.setHiddenWords(next);
    _c.clear();
    setState(() => _words = next);
  }

  Future<void> _remove(String w) async {
    final next = _words.where((x) => x != w).toList();
    await AppSettingsService.setHiddenWords(next);
    setState(() => _words = next);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('छिपे शब्द')),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('इन शब्दों वाले मैसेज छिपाओ',
                style: TextStyle(color: Colors.white)),
            subtitle: const Text(
                'नीचे लिखे शब्द वाले आने वाले चैट मैसेज छिपा दिए जाते हैं। '
                'छिपे मैसेज को देखने के लिए उस पर टैप करो।',
                style: TextStyle(color: Colors.white54, fontSize: 12)),
            value: _on,
            onChanged: (v) async {
              await AppSettingsService.setHiddenWordsOn(v);
              setState(() => _on = v);
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _c,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                        hintText: 'कोई शब्द या वाक्य जोड़ो'),
                    onSubmitted: (_) => _add(),
                  ),
                ),
                IconButton(
                    icon: const Icon(Icons.add_circle, color: _pink),
                    onPressed: _add),
              ],
            ),
          ),
          _hdr('आपके छिपे शब्द'),
          if (_words.isEmpty) _note('अभी कोई शब्द नहीं जोड़ा गया।'),
          for (final w in _words)
            ListTile(
              title: Text(w, style: const TextStyle(color: Colors.white)),
              trailing: IconButton(
                icon: const Icon(Icons.close, color: Colors.white54),
                onPressed: () => _remove(w),
              ),
            ),
          _note('इसी फोन में सेव रहता है।'),
        ],
      ),
    );
  }
}

// ======================================================================
// YOUR ACTIVITY + TIME MANAGEMENT (real foreground-time tracking)
// ======================================================================
class TimeManagementScreen extends StatefulWidget {
  const TimeManagementScreen({Key? key}) : super(key: key);
  @override
  State<TimeManagementScreen> createState() => _TimeManagementState();
}

class _TimeManagementState extends State<TimeManagementScreen> {
  int _today = 0;
  int _limit = 0;
  Map<String, int> _usage = <String, int>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final today = await UsageTimeService.instance.todaySeconds();
    final limit = await AppSettingsService.getDailyLimitMinutes();
    final usage = await AppSettingsService.getUsageMap();
    if (mounted) {
      setState(() {
        _today = today;
        _limit = limit;
        _usage = usage;
      });
    }
  }

  Future<void> _setLimit(int minutes) async {
    await AppSettingsService.setDailyLimitMinutes(minutes);
    UsageTimeService.instance.resetReminder();
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final days = List.generate(7, (i) => now.subtract(Duration(days: i)));
    var maxSec = 1;
    for (final d in days) {
      final v = d.day == now.day && d.month == now.month
          ? _today
          : (_usage[UsageTimeService.dayKey(d)] ?? 0);
      if (v > maxSec) maxSec = v;
    }
    return Scaffold(
      appBar: AppBar(title: const Text('आपकी गतिविधि और समय')),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text('आज ऐप में बिताया समय',
                    style: TextStyle(color: Colors.white54)),
                const SizedBox(height: 6),
                Text(_fmt(_today),
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 36,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          _hdr('पिछले 7 दिन'),
          for (final d in days)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Row(
                children: [
                  SizedBox(
                    width: 84,
                    child: Text(UsageTimeService.dayKey(d).substring(5),
                        style: const TextStyle(color: Colors.white70)),
                  ),
                  Expanded(
                    child: LinearProgressIndicator(
                      value: (d.day == now.day && d.month == now.month
                              ? _today
                              : (_usage[UsageTimeService.dayKey(d)] ?? 0)) /
                          maxSec,
                      color: _pink,
                      backgroundColor: Colors.white12,
                      minHeight: 8,
                    ),
                  ),
                  SizedBox(
                    width: 64,
                    child: Text(
                      _fmt(d.day == now.day && d.month == now.month
                          ? _today
                          : (_usage[UsageTimeService.dayKey(d)] ?? 0)),
                      textAlign: TextAlign.right,
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                ],
              ),
            ),
          _hdr('रोज़ की लिमिट का रिमाइंडर'),
          _choice('बंद', null, _limit == 0, () => _setLimit(0)),
          for (final m in const [15, 30, 60, 90, 120])
            _choice('$m मिनट', null, _limit == m, () => _setLimit(m)),
          _note('समय सिर्फ़ तब गिना जाता है जब ऐप स्क्रीन पर खुला हो, और यह '
              'इसी फोन में सेव रहता है। लिमिट पूरी होने पर आपको दिन में एक बार '
              'रिमाइंडर मिलता है।'),
        ],
      ),
    );
  }
}

// ======================================================================
// ACCESSIBILITY (text size + bold text apply to the whole app instantly)
// ======================================================================
class AccessibilityScreen extends StatelessWidget {
  const AccessibilityScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('एक्सेसिबिलिटी')),
      body: ValueListenableBuilder<double>(
        valueListenable: AppSettingsService.textScale,
        builder: (context, scale, _) => ValueListenableBuilder<bool>(
          valueListenable: AppSettingsService.boldText,
          builder: (context, bold, __) => ListView(
            children: [
              _hdr('टेक्स्ट साइज़'),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    const Text('A', style: TextStyle(color: Colors.white70)),
                    Expanded(
                      child: Slider(
                        min: 0.85,
                        max: 1.5,
                        divisions: 13,
                        value: scale.clamp(0.85, 1.5).toDouble(),
                        activeColor: _pink,
                        label: '${(scale * 100).round()}%',
                        onChanged: (v) => AppSettingsService.setTextScale(v),
                      ),
                    ),
                    const Text('A',
                        style: TextStyle(color: Colors.white70, fontSize: 24)),
                  ],
                ),
              ),
              _note('नमूना: यह टेक्स्ट साइज़ का पूर्वावलोकन है।'),
              SwitchListTile(
                title: const Text('बोल्ड टेक्स्ट',
                    style: TextStyle(color: Colors.white)),
                value: bold,
                onChanged: (v) => AppSettingsService.setBoldText(v),
              ),
              ListTile(
                title: const Text('डिफ़ॉल्ट पर वापस',
                    style: TextStyle(color: Colors.white)),
                leading: const Icon(Icons.restart_alt, color: Colors.white70),
                onTap: () {
                  AppSettingsService.setTextScale(1.0);
                  AppSettingsService.setBoldText(false);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ======================================================================
// DATA USAGE & MEDIA QUALITY (used by camera_screen + video_call_screen)
// ======================================================================
class DataUsageScreen extends StatefulWidget {
  const DataUsageScreen({Key? key}) : super(key: key);
  @override
  State<DataUsageScreen> createState() => _DataUsageState();
}

class _DataUsageState extends State<DataUsageScreen> {
  String _cam = 'high';
  String _call = 'auto';

  @override
  void initState() {
    super.initState();
    AppSettingsService.getCameraQuality().then((v) {
      if (mounted) setState(() => _cam = v);
    });
    AppSettingsService.getCallQuality().then((v) {
      if (mounted) setState(() => _call = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('डेटा उपयोग और मीडिया क्वालिटी')),
      body: ListView(
        children: [
          _hdr('कैमरा क्वालिटी (रील / स्टोरी)'),
          _choice('स्टैंडर्ड', 'छोटी फाइलें, कम स्टोरेज', _cam == 'standard',
              () async {
            await AppSettingsService.setCameraQuality('standard');
            setState(() => _cam = 'standard');
          }),
          _choice('हाई', 'सुझाया गया', _cam == 'high', () async {
            await AppSettingsService.setCameraQuality('high');
            setState(() => _cam = 'high');
          }),
          _choice('अधिकतम', 'सबसे अच्छी क्वालिटी, सबसे बड़ी फाइलें', _cam == 'max',
              () async {
            await AppSettingsService.setCameraQuality('max');
            setState(() => _cam = 'max');
          }),
          _hdr('वीडियो कॉल क्वालिटी'),
          _choice('डेटा सेवर', '480x360, 15 fps', _call == 'saver', () async {
            await AppSettingsService.setCallQuality('saver');
            setState(() => _call = 'saver');
          }),
          _choice('ऑटोमैटिक', 'आपके नेटवर्क के हिसाब से अपने-आप बदलता है', _call == 'auto',
              () async {
            await AppSettingsService.setCallQuality('auto');
            setState(() => _call = 'auto');
          }),
          _choice('हाई', '1280x720, 30 fps (ज़्यादा डेटा लगता है)', _call == 'high',
              () async {
            await AppSettingsService.setCallQuality('high');
            setState(() => _call = 'high');
          }),
          _note('बदलाव अगली बार कैमरा खोलने या कॉल शुरू करने पर लागू होंगे।'),
        ],
      ),
    );
  }
}

// ======================================================================
// ACCOUNT STATUS (real data from Firestore + FirebaseAuth)
// ======================================================================
class AccountStatusScreen extends StatelessWidget {
  const AccountStatusScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    final uid = user.uid;
    final db = FirebaseFirestore.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('अकाउंट स्टेटस')),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: db.collection('users').doc(uid).snapshots(),
        builder: (context, snap) {
          final d = snap.data?.data() ?? <String, dynamic>{};
          final created = (d['createdAt'] as Timestamp?)?.toDate();
          final premUntil = (d['premiumUntil'] as Timestamp?)?.toDate();
          final premium = d['isPremium'] == true &&
              premUntil != null &&
              premUntil.isAfter(DateTime.now());
          Widget row(String k, String v) => ListTile(
                title: Text(k, style: const TextStyle(color: Colors.white54)),
                subtitle: Text(v, style: const TextStyle(color: Colors.white)),
              );
          return ListView(
            children: [
              row('नाम', (d['displayName'] ?? user.displayName ?? '—').toString()),
              row('ईमेल', (d['email'] ?? user.email ?? '—').toString()),
              row('लॉगिन का तरीका', (d['authProvider'] ?? '—').toString()),
              row('अकाउंट का प्रकार', (d['userType'] ?? '—').toString()),
              row('अकाउंट प्राइवेसी', d['isPrivate'] == true ? 'प्राइवेट' : 'पब्लिक'),
              row('सदस्य बनने की तारीख',
                  created == null ? '—' : created.toLocal().toString().substring(0, 10)),
              row('प्रीमियम',
                  premium ? '${premUntil!.toLocal().toString().substring(0, 10)} तक चालू' : 'सब्सक्राइब नहीं किया'),
              row('कॉइन बैलेंस', '${(d['coinBalance'] as num?)?.toInt() ?? 0}'),
              StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: db.collection('users').doc(uid).collection('followers').snapshots(),
                builder: (c, s) => row('फॉलोवर्स', '${s.data?.docs.length ?? 0}'),
              ),
              StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: db.collection('users').doc(uid).collection('following').snapshots(),
                builder: (c, s) => row('फॉलोइंग', '${s.data?.docs.length ?? 0}'),
              ),
              StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: db.collection('users').doc(uid).collection('blocked').snapshots(),
                builder: (c, s) => row('ब्लॉक किए गए अकाउंट', '${s.data?.docs.length ?? 0}'),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ======================================================================
// ACCOUNT & SECURITY: password reset email, sign out, delete account
// ======================================================================
class AccountSecurityScreen extends StatefulWidget {
  const AccountSecurityScreen({Key? key}) : super(key: key);
  @override
  State<AccountSecurityScreen> createState() => _AccountSecurityState();
}

class _AccountSecurityState extends State<AccountSecurityScreen> {
  bool _busy = false;

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _resetPassword() async {
    final user = FirebaseAuth.instance.currentUser!;
    final hasPassword = user.providerData.any((p) => p.providerId == 'password');
    if (!hasPassword || user.email == null) {
      _snack('यह अकाउंट Google या Truecaller से लॉगिन होता है, इसलिए इसमें '
          'बदलने के लिए ऐप का पासवर्ड नहीं है।');
      return;
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: user.email!);
      _snack('पासवर्ड रीसेट ईमेल ${user.email} पर भेज दिया गया');
    } on FirebaseAuthException catch (e) {
      _snack(e.message ?? 'ईमेल नहीं भेजा जा सका');
    }
  }

  Future<void> _deleteRefs(List<DocumentReference> refs) async {
    final db = FirebaseFirestore.instance;
    for (var i = 0; i < refs.length; i += 400) {
      final batch = db.batch();
      for (final r in refs.skip(i).take(400)) {
        batch.delete(r);
      }
      await batch.commit();
    }
  }

  Future<void> _deleteAccount() async {
    final user = FirebaseAuth.instance.currentUser!;
    final uid = user.uid;

    final typed = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('अकाउंट हमेशा के लिए डिलीट करें?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('आपकी प्रोफाइल, फॉलोवर्स, फॉलोइंग और ब्लॉक लिस्ट '
                'मिटा दी जाएगी। इसे वापस नहीं किया जा सकता। पक्का करने के लिए DELETE टाइप करो।'),
            TextField(controller: typed),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('रद्द करो')),
          TextButton(
            onPressed: () => Navigator.pop(c, typed.text.trim() == 'DELETE'),
            child: const Text('डिलीट', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    typed.dispose();
    if (ok != true) return;

    // Firebase only allows deleting an account shortly after signing in.
    final tok = await user.getIdTokenResult();
    final authTime = tok.authTime;
    if (authTime == null ||
        DateTime.now().difference(authTime) > const Duration(minutes: 4)) {
      _snack('सुरक्षा के लिए लॉग आउट करो, दोबारा लॉगिन करो, फिर कुछ ही '
          'मिनट में डिलीट करो। अभी कुछ भी डिलीट नहीं हुआ।');
      return;
    }

    setState(() => _busy = true);
    try {
      final db = FirebaseFirestore.instance;
      final me = db.collection('users').doc(uid);

      final following = await me.collection('following').get();
      final followers = await me.collection('followers').get();
      final blocked = await me.collection('blocked').get();

      final refs = <DocumentReference>[
        // remove me from other people's follower lists
        for (final d in following.docs)
          db.collection('users').doc(d.id).collection('followers').doc(uid),
        // remove me from other people's following lists
        for (final d in followers.docs)
          db.collection('users').doc(d.id).collection('following').doc(uid),
        ...following.docs.map((d) => d.reference),
        ...followers.docs.map((d) => d.reference),
        ...blocked.docs.map((d) => d.reference),
      ];
      await _deleteRefs(refs);
      await me.delete();
      await user.delete();
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } on FirebaseAuthException catch (e) {
      _snack(e.message ?? 'अकाउंट डिलीट नहीं हो सका');
    } catch (e) {
      _snack('अकाउंट डिलीट नहीं हो सका: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return Scaffold(
      appBar: AppBar(title: const Text('अकाउंट और सुरक्षा')),
      body: _busy
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                ListTile(
                  leading: const Icon(Icons.person_outline, color: Colors.white70),
                  title: Text(user.displayName ?? user.email ?? user.uid,
                      style: const TextStyle(color: Colors.white)),
                  subtitle: Text(user.email ?? '',
                      style: const TextStyle(color: Colors.white54)),
                ),
                ListTile(
                  leading: const Icon(Icons.lock_reset, color: Colors.white70),
                  title: const Text('पासवर्ड बदलो (ईमेल लिंक से)',
                      style: TextStyle(color: Colors.white)),
                  onTap: _resetPassword,
                ),
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.white70),
                  title: const Text('लॉग आउट', style: TextStyle(color: Colors.white)),
                  onTap: () async {
                    await AuthService().signOut();
                    if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                  },
                ),
                _hdr('खतरे वाला हिस्सा'),
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
                  title: const Text('अकाउंट डिलीट करो',
                      style: TextStyle(color: Colors.redAccent)),
                  onTap: _deleteAccount,
                ),
              ],
            ),
    );
  }
}

// ======================================================================
// ORDERS & PAYMENTS (real premium status, coin balance, gift history)
// ======================================================================
class OrdersPaymentsScreen extends StatelessWidget {
  const OrdersPaymentsScreen({Key? key}) : super(key: key);

  Future<List<Map<String, dynamic>>> _gifts(String uid) async {
    final col = FirebaseFirestore.instance.collection('giftTransactions');
    final sent = await col.where('fromUid', isEqualTo: uid).get();
    final got = await col.where('toUid', isEqualTo: uid).get();
    final all = <Map<String, dynamic>>[
      for (final d in sent.docs) {...d.data(), 'dir': 'sent'},
      for (final d in got.docs) {...d.data(), 'dir': 'received'},
    ];
    all.sort((a, b) {
      final ta = (a['sentAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0;
      final tb = (b['sentAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0;
      return tb.compareTo(ta);
    });
    return all;
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('ऑर्डर और पेमेंट')),
      body: ListView(
        children: [
          StreamBuilder<bool>(
            stream: SubscriptionService().isPremiumStream(),
            builder: (c, s) => ListTile(
              leading: const Icon(Icons.verified_outlined, color: Colors.white70),
              title: const Text('प्रीमियम (ब्लू बैज)',
                  style: TextStyle(color: Colors.white)),
              trailing: Text((s.data ?? false) ? 'चालू' : 'सब्सक्राइब नहीं किया',
                  style: const TextStyle(color: Colors.white54)),
            ),
          ),
          StreamBuilder<int>(
            stream: CoinWalletService().myBalanceStream(),
            builder: (c, s) => ListTile(
              leading: const Icon(Icons.monetization_on_outlined, color: Colors.white70),
              title: const Text('कॉइन बैलेंस', style: TextStyle(color: Colors.white)),
              trailing: Text('${s.data ?? 0}',
                  style: const TextStyle(color: Colors.white54)),
            ),
          ),
          _hdr('गिफ्ट हिस्ट्री'),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _gifts(uid),
            builder: (c, s) {
              if (s.connectionState != ConnectionState.done) {
                return const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: CircularProgressIndicator()));
              }
              if (s.hasError) return _note('गिफ्ट हिस्ट्री लोड नहीं हो सकी।');
              final list = s.data ?? [];
              if (list.isEmpty) return _note('अभी तक कोई गिफ्ट भेजा या मिला नहीं है।');
              return Column(
                children: [
                  for (final g in list)
                    ListTile(
                      leading: Icon(
                          g['dir'] == 'sent' ? Icons.north_east : Icons.south_west,
                          color: g['dir'] == 'sent'
                              ? Colors.orangeAccent
                              : Colors.greenAccent),
                      title: Text(
                          '${g['dir'] == 'sent' ? 'भेजे' : 'मिले'} ${g['coins']} कॉइन',
                          style: const TextStyle(color: Colors.white)),
                      subtitle: Text(
                          ((g['sentAt'] as Timestamp?)?.toDate().toLocal().toString() ?? '')
                              .split('.')
                              .first,
                          style: const TextStyle(color: Colors.white54, fontSize: 12)),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
