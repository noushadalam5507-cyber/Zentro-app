import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'privacy_service.dart';

/// Firestore structure used by this service:
///
/// users/{uid}                          -> { displayName, email, photoUrl,
///                                            userType, authProvider, createdAt }
/// users/{uid}/followers/{followerUid}  -> { since: Timestamp }
/// users/{uid}/following/{followingUid} -> { since: Timestamp }
/// chats/{chatId}/messages/{messageId}  -> { senderId, text, sentAt }
///
/// chatId is built deterministically from the two user IDs so both users
/// always land in the same chat document (see chatIdFor()).
class SocialService {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  String get _myUid => _auth.currentUser!.uid;

  /// Every account is registered as a Main User, no matter how it was
  /// created (Google, Truecaller, or name + email + password).
  static const String mainUserType = 'main_user';

  /// Call after every sign-in so this user has a profile document.
  ///
  /// - New user  -> document is created with userType = 'main_user'.
  /// - Old user  -> profile fields are refreshed, and userType is filled in
  ///   if the account predates this field. An existing userType is never
  ///   overwritten (Firestore rules enforce that too).
  Future<void> ensureUserProfile() async {
    final user = _auth.currentUser;
    if (user == null) return;

    final ref = _db.collection('users').doc(user.uid);
    final snap = await ref.get();

    final data = <String, dynamic>{
      'displayName': user.displayName ?? '',
      'email': user.email ?? '',
      'photoUrl': user.photoURL ?? '',
    };

    if (!snap.exists) {
      data['userType'] = mainUserType;
      data['authProvider'] = _providerOf(user);
      data['createdAt'] = FieldValue.serverTimestamp();
    } else if (snap.data()?['userType'] == null) {
      data['userType'] = mainUserType;
    }

    await ref.set(data, SetOptions(merge: true));
  }

  /// Which sign-in method created this account (for reference only).
  String _providerOf(User user) {
    if (user.uid.startsWith('tc_')) return 'truecaller';
    final ids = user.providerData.map((p) => p.providerId);
    if (ids.contains('google.com')) return 'google';
    if (ids.contains('password')) return 'email';
    return 'other';
  }

  // ---------------- FOLLOW SYSTEM ----------------

  Future<void> followUser(String otherUid) async {
    final batch = _db.batch();
    batch.set(
      _db.collection('users').doc(otherUid).collection('followers').doc(_myUid),
      {'since': FieldValue.serverTimestamp()},
    );
    batch.set(
      _db.collection('users').doc(_myUid).collection('following').doc(otherUid),
      {'since': FieldValue.serverTimestamp()},
    );
    await batch.commit();
  }

  Future<void> unfollowUser(String otherUid) async {
    final batch = _db.batch();
    batch.delete(
      _db.collection('users').doc(otherUid).collection('followers').doc(_myUid),
    );
    batch.delete(
      _db.collection('users').doc(_myUid).collection('following').doc(otherUid),
    );
    await batch.commit();
  }

  /// Real count, always reflects the true number of documents —
  /// nothing here is ever hardcoded or faked for a specific account.
  Stream<int> followerCount(String uid) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('followers')
        .snapshots()
        .map((snap) => snap.docs.length);
  }

  /// The account's own email, as written into Firestore straight from
  /// FirebaseAuth at sign-in (see ensureUserProfile). Used only to decide
  /// whether to show the Founder/Admin badge — Firestore rules should keep
  /// this field write-restricted to the owning uid so it can't be spoofed.
  Stream<String?> emailStream(String uid) {
    return _db
        .collection('users')
        .doc(uid)
        .snapshots()
        .map((doc) => doc.data()?['email'] as String?);
  }

  Stream<bool> isFollowing(String otherUid) {
    return _db
        .collection('users')
        .doc(_myUid)
        .collection('following')
        .doc(otherUid)
        .snapshots()
        .map((doc) => doc.exists);
  }

  // ---------------- MESSAGING ----------------

  String chatIdFor(String otherUid) {
    final ids = [_myUid, otherUid]..sort();
    return ids.join('_');
  }

  Future<void> sendMessage(String otherUid, String text) async {
    final reason = await PrivacyService().messageBlockReason(otherUid);
    if (reason != null) throw Exception(reason);
    final chatId = chatIdFor(otherUid);
    await _db.collection('chats').doc(chatId).collection('messages').add({
      'senderId': _myUid,
      'recipientId': otherUid,
      'text': text,
      'sentAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> messagesStream(String otherUid) {
    final chatId = chatIdFor(otherUid);
    return _db
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('sentAt', descending: false)
        .snapshots();
  }
}
