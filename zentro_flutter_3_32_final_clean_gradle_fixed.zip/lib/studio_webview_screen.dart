import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:permission_handler/permission_handler.dart';

/// Zentro Web Studio: the web-based studio (from the old "fullplayer" package)
/// opened inside the app. Camera/mic permission requests are granted ONLY for
/// the studio's own host, not for any other site the WebView might navigate to.
class StudioWebViewScreen extends StatefulWidget {
  const StudioWebViewScreen({Key? key}) : super(key: key);

  static const String studioUrl =
      'https://ais-dev-i3x6jhgyj7s7bngzng5uo6-561648828287.asia-southeast1.run.app';

  @override
  State<StudioWebViewScreen> createState() => _StudioWebViewScreenState();
}

class _StudioWebViewScreenState extends State<StudioWebViewScreen> {
  InAppWebViewController? _controller;
  double _progress = 0;
  bool _loading = true;

  final String _studioHost = Uri.parse(StudioWebViewScreen.studioUrl).host;

  @override
  void initState() {
    super.initState();
    [Permission.camera, Permission.microphone].request();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_controller != null && await _controller!.canGoBack()) {
          _controller!.goBack();
          return false;
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF07020D),
        body: SafeArea(
          child: Stack(
            children: [
              InAppWebView(
                initialUrlRequest:
                    URLRequest(url: WebUri(StudioWebViewScreen.studioUrl)),
                initialSettings: InAppWebViewSettings(
                  mediaPlaybackRequiresUserGesture: false,
                  allowsInlineMediaPlayback: true,
                  iframeAllow: 'camera; microphone; display-capture; autoplay',
                  iframeAllowFullscreen: true,
                  cacheEnabled: true,
                  javaScriptEnabled: true,
                  supportZoom: false,
                  transparentBackground: true,
                ),
                onWebViewCreated: (c) => _controller = c,
                onPermissionRequest: (c, request) async {
                  final ok = request.origin.host == _studioHost;
                  return PermissionResponse(
                    resources: request.resources,
                    action: ok
                        ? PermissionResponseAction.GRANT
                        : PermissionResponseAction.DENY,
                  );
                },
                onProgressChanged: (c, p) {
                  setState(() {
                    _progress = p / 100;
                    if (p == 100) _loading = false;
                  });
                },
              ),
              if (_loading)
                Container(
                  color: const Color(0xFF07020D),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('ZENTRO 4K STUDIO',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 3)),
                        const SizedBox(height: 6),
                        const Text('Founder: MD Naushad Alam',
                            style:
                                TextStyle(color: Colors.white70, fontSize: 13)),
                        const SizedBox(height: 24),
                        SizedBox(
                          width: 180,
                          child: LinearProgressIndicator(
                            value: _progress > 0 ? _progress : null,
                            color: const Color(0xFFFF1493),
                            backgroundColor: Colors.white12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              Positioned(
                top: 4,
                left: 4,
                child: IconButton(
                  icon: const Icon(Icons.close, color: Colors.white70),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
