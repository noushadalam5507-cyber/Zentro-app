import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Reads premium status. This class deliberately has NO method that sets
/// `isPremium` or `premiumUntil` from the client — those fields must only
/// ever be written by your Cloud Function after it verifies a real payment
/// (Razorpay/Stripe webhook signature). Add this to your Firestore Security
/// Rules so the client literally cannot cheat it:
///
///   match /users/{uid} {
///     allow write: if request.auth.uid == uid
///       && !("isPremium" in request.resource.data.diff(resource.data).affectedKeys())
///       && !("premiumUntil" in request.resource.data.diff(resource.data).affectedKeys());
///   }
///
/// users/{uid} gains two fields, both server-written:
///   isPremium: bool
///   premiumUntil: Timestamp
class SubscriptionService {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  String get _myUid => _auth.currentUser!.uid;

  Stream<bool> isPremiumStream([String? uid]) {
    return _db.collection('users').doc(uid ?? _myUid).snapshots().map((doc) {
      final data = doc.data();
      if (data == null) return false;
      final isPremium = data['isPremium'] == true;
      final until = (data['premiumUntil'] as Timestamp?)?.toDate();
      if (!isPremium || until == null) return false;
      return until.isAfter(DateTime.now());
    });
  }
}
