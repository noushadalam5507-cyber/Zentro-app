import 'dart:async';
import 'dart:math';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:truecaller_sdk/truecaller_sdk.dart';

/// Thrown when Truecaller sign-in can't proceed (Truecaller app missing,
/// user dismissed the sheet, server rejected the login, ...).
class TruecallerAuthException implements Exception {
  final String message;
  const TruecallerAuthException(this.message);
  @override
  String toString() => message;
}

/// Truecaller Sign-in.
///
/// The Client ID (zfnc12kq...) lives in AndroidManifest.xml
/// (`com.truecaller.android.sdk.ClientId`) — that's where the SDK reads it.
///
/// Flow:
///  1. SDK shows Truecaller's consent sheet and returns an authorization code
///     (PKCE: we hold the code verifier, so the code is useless to anyone else).
///  2. The code + verifier go to the `truecallerSignIn` Cloud Function
///     (backend/functions/index.js), which exchanges them with Truecaller,
///     reads the verified profile and returns a Firebase custom token.
///  3. We sign in to Firebase with that token, so a Truecaller user is a
///     normal Firebase user like any other.
///
/// Only users who have the Truecaller app are supported
/// (OPTION_VERIFY_ONLY_TC_USERS) — this avoids the call-log / phone-state
/// permissions that the "verify everyone" mode needs. Everyone else can use
/// Google or Email.
class TruecallerAuthService {
  Future<User> signIn() async {
    TcSdk.initializeSDK(
      sdkOption: TcSdkOptions.OPTION_VERIFY_ONLY_TC_USERS,
    );

    final usable = await TcSdk.isOAuthFlowUsable;
    if (!usable) {
      throw const TruecallerAuthException(
        'Truecaller isn\'t available on this device. '
        'Please use Google or Email instead.',
      );
    }

    final state = _randomString(24);
    TcSdk.setOAuthState(state);
    TcSdk.setOAuthScopes(['profile', 'phone', 'openid']);

    final codeVerifier = await TcSdk.generateRandomCodeVerifier;
    final codeChallenge = await TcSdk.generateCodeChallenge(codeVerifier);
    if (codeChallenge == null) {
      throw const TruecallerAuthException(
        'This device isn\'t supported by Truecaller sign-in.',
      );
    }
    TcSdk.setCodeChallenge(codeChallenge);

    // Listen BEFORE asking for the code so no callback can be missed.
    final completer = Completer<TcOAuthData>();
    final sub = TcSdk.streamCallbackData.listen((cb) {
      if (completer.isCompleted) return;
      switch (cb.result) {
        case TcSdkCallbackResult.success:
          final data = cb.tcOAuthData;
          if (data == null) {
            completer.completeError(const TruecallerAuthException(
                'Truecaller returned no data. Please try again.'));
          } else {
            completer.complete(data);
          }
          break;
        case TcSdkCallbackResult.failure:
          completer.completeError(TruecallerAuthException(
              cb.error?.message ?? 'Truecaller sign-in was cancelled.'));
          break;
        case TcSdkCallbackResult.verification:
          completer.completeError(const TruecallerAuthException(
              'Truecaller couldn\'t verify you automatically. '
              'Please use Google or Email instead.'));
          break;
        default:
          break;
      }
    });

    TcSdk.getAuthorizationCode; // opens Truecaller's consent sheet

    final TcOAuthData data = await completer.future
        .timeout(
          const Duration(minutes: 3),
          onTimeout: () => throw const TruecallerAuthException(
              'Truecaller sign-in timed out. Please try again.'),
        )
        .whenComplete(() => sub.cancel());

    // CSRF protection: state we set must come back unchanged.
    if (data.state != state) {
      throw const TruecallerAuthException(
          'Truecaller sign-in couldn\'t be verified. Please try again.');
    }

    try {
      final result = await FirebaseFunctions.instance
          .httpsCallable('truecallerSignIn')
          .call<Map<dynamic, dynamic>>({
        'authorizationCode': data.authorizationCode,
        'codeVerifier': codeVerifier,
      });
      final customToken = result.data['customToken'] as String?;
      if (customToken == null || customToken.isEmpty) {
        throw const TruecallerAuthException(
            'Server didn\'t return a login token. Please try again.');
      }
      final cred = await FirebaseAuth.instance.signInWithCustomToken(customToken);
      return cred.user!;
    } on FirebaseFunctionsException catch (e) {
      if (e.code == 'not-found' || e.code == 'unimplemented') {
        throw const TruecallerAuthException(
            'Truecaller login isn\'t set up on the server yet '
            '(deploy the "truecallerSignIn" Cloud Function).');
      }
      throw TruecallerAuthException(
          e.message ?? 'Truecaller login failed. Please try again.');
    }
  }

  static String _randomString(int length) {
    const chars =
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final rnd = Random.secure();
    return List.generate(length, (_) => chars[rnd.nextInt(chars.length)]).join();
  }
}
