import 'dart:async';
import 'package:flutter/material.dart';
import 'app_settings_service.dart';

/// Counts real foreground time (only while the app is visible) per day and,
/// if the user set a daily limit, shows a reminder once the limit is reached.
class UsageTimeService with WidgetsBindingObserver {
  UsageTimeService._();
  static final UsageTimeService instance = UsageTimeService._();

  GlobalKey<NavigatorState>? _navKey;
  Timer? _timer;
  DateTime? _lastTick;
  String _todayKey = '';
  int _todaySeconds = 0;
  bool _reminderShownToday = false;
  bool _started = false;

  static String dayKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> start(GlobalKey<NavigatorState> navKey) async {
    if (_started) return;
    _started = true;
    _navKey = navKey;
    WidgetsBinding.instance.addObserver(this);
    _todayKey = dayKey(DateTime.now());
    _todaySeconds = await AppSettingsService.getUsageSeconds(_todayKey);
    _resume();
  }

  void _resume() {
    _lastTick = DateTime.now();
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _tick());
  }

  Future<void> _pause() async {
    await _tick();
    _timer?.cancel();
    _timer = null;
    _lastTick = null;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _resume();
    } else {
      _pause();
    }
  }

  Future<void> _tick() async {
    final now = DateTime.now();
    final key = dayKey(now);
    if (key != _todayKey) {
      _todayKey = key;
      _todaySeconds = 0;
      _reminderShownToday = false;
      _lastTick = now;
      return;
    }
    final last = _lastTick;
    _lastTick = now;
    if (last == null) return;
    final delta = now.difference(last).inSeconds;
    if (delta <= 0) return;
    _todaySeconds += delta;
    await AppSettingsService.setUsageSeconds(_todayKey, _todaySeconds);
    await _checkLimit();
  }

  /// Seconds used today, including the time since the last tick.
  Future<int> todaySeconds() async {
    await _tick();
    return _todaySeconds;
  }

  /// Call after the user changes the limit so the reminder can fire again.
  void resetReminder() => _reminderShownToday = false;

  Future<void> _checkLimit() async {
    if (_reminderShownToday) return;
    final limit = await AppSettingsService.getDailyLimitMinutes();
    if (limit <= 0) return;
    if (_todaySeconds < limit * 60) return;
    final ctx = _navKey?.currentContext;
    if (ctx == null) return;
    _reminderShownToday = true;
    // ignore: use_build_context_synchronously
    showDialog<void>(
      context: ctx,
      builder: (c) => AlertDialog(
        title: const Text('रोज़ की लिमिट पूरी हो गई'),
        content: Text(
            "आपने आज ऐप में $limit मिनट बिता लिए हैं, जो आपकी तय की हुई लिमिट है। थोड़ा ब्रेक लें?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('जारी रखो')),
        ],
      ),
    );
  }
}
