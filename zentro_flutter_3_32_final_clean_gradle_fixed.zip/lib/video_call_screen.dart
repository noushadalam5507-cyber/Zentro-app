import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'app_settings_service.dart';
import 'agora_config.dart';
import 'interstitial_ad_service.dart';
import 'gifting_widget.dart';

class VideoCallScreen extends StatefulWidget {
  final String channelName;
  final bool audioOnly; // true = voice call, false = video call
  // Set this when this call is a "live" session with a host who can
  // receive gifts (e.g. calling a creator). Leave null for a plain 1:1
  // call between two friends with no gifting.
  final String? hostUidForGifting;

  const VideoCallScreen({
    Key? key,
    this.channelName = AgoraConfig.defaultChannelName,
    this.audioOnly = false,
    this.hostUidForGifting,
  }) : super(key: key);

  @override
  State<VideoCallScreen> createState() => _VideoCallScreenState();
}

class _VideoCallScreenState extends State<VideoCallScreen> {
  late final RtcEngine _engine;
  bool _localUserJoined = false;
  int? _remoteUid;
  bool _muted = false;
  bool _cameraOff = false;
  bool _engineReady = false;

  @override
  void initState() {
    super.initState();
    InterstitialAdService().preload(); // ready before the call even ends
    _initAgora();
  }

  Future<void> _initAgora() async {
    // Ask for camera + mic permission before joining
    await [Permission.camera, Permission.microphone].request();

    _engine = createAgoraRtcEngine();
    await _engine.initialize(
      RtcEngineContext(
        appId: AgoraConfig.appId,
        channelProfile: ChannelProfileType.channelProfileCommunication,
      ),
    );

    _engine.registerEventHandler(
      RtcEngineEventHandler(
        onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
          setState(() => _localUserJoined = true);
        },
        onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
          setState(() => _remoteUid = remoteUid);
        },
        onUserOffline: (RtcConnection connection, int remoteUid,
            UserOfflineReasonType reason) {
          setState(() => _remoteUid = null);
        },
        onError: (ErrorCodeType err, String msg) {
          debugPrint("Agora error: $err - $msg");
        },
      ),
    );

    if (widget.audioOnly) {
      await _engine.disableVideo();
    } else {
      await _engine.enableVideo();
      final q = await AppSettingsService.getCallQuality();
      if (q != 'auto') {
        final saver = q == 'saver';
        await _engine.setVideoEncoderConfiguration(
          VideoEncoderConfiguration(
            dimensions: saver
                ? const VideoDimensions(width: 480, height: 360)
                : const VideoDimensions(width: 1280, height: 720),
            frameRate: saver ? 15 : 30,
            bitrate: 0,
          ),
        );
      }
      await _engine.startPreview();
    }

    await _engine.joinChannel(
      token: AgoraConfig.tempToken,
      channelId: widget.channelName,
      uid: 0,
      options: const ChannelMediaOptions(
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
        channelProfile: ChannelProfileType.channelProfileCommunication,
      ),
    );

    setState(() => _engineReady = true);
  }

  @override
  void dispose() {
    if (_engineReady) {
      _engine.leaveChannel();
      _engine.release();
    }
    // Major transition point: call just ended.
    InterstitialAdService().maybeShow();
    super.dispose();
  }

  Widget _remoteVideo() {
    if (widget.audioOnly) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircleAvatar(radius: 50, child: Icon(Icons.person, size: 50)),
            const SizedBox(height: 16),
            Text(
              _remoteUid != null ? "Connected" : "Calling...",
              style: const TextStyle(color: Colors.white70),
            ),
          ],
        ),
      );
    }
    if (_remoteUid != null) {
      return AgoraVideoView(
        controller: VideoViewController.remote(
          rtcEngine: _engine,
          canvas: VideoCanvas(uid: _remoteUid),
          connection: RtcConnection(channelId: widget.channelName),
        ),
      );
    } else {
      return const Center(
        child: Text(
          "Waiting for the other user to join...",
          style: TextStyle(color: Colors.white70),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Remote user's video, full screen
          Positioned.fill(child: _remoteVideo()),

          // Local user's small preview, top-right corner
          if (_localUserJoined && !widget.audioOnly)
            Positioned(
              top: 40,
              right: 16,
              width: 110,
              height: 150,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: _engine,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                ),
              ),
            ),

          // Bottom controls
          Positioned(
            bottom: 30,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _controlButton(
                  icon: _muted ? Icons.mic_off : Icons.mic,
                  onTap: () {
                    setState(() => _muted = !_muted);
                    _engine.muteLocalAudioStream(_muted);
                  },
                ),
                const SizedBox(width: 20),
                _controlButton(
                  icon: Icons.call_end,
                  color: Colors.red,
                  onTap: () => Navigator.pop(context),
                ),
                const SizedBox(width: 20),
                if (!widget.audioOnly)
                  _controlButton(
                    icon: _cameraOff ? Icons.videocam_off : Icons.videocam,
                    onTap: () {
                      setState(() => _cameraOff = !_cameraOff);
                      _engine.muteLocalVideoStream(_cameraOff);
                    },
                  ),
                if (widget.hostUidForGifting != null) ...[
                  const SizedBox(width: 20),
                  GiftButton(hostUid: widget.hostUidForGifting!),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _controlButton({
    required IconData icon,
    required VoidCallback onTap,
    Color color = Colors.white24,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: CircleAvatar(
        radius: 28,
        backgroundColor: color,
        child: Icon(icon, color: Colors.white),
      ),
    );
  }
}
