import 'package:speech_to_text/speech_to_text.dart';

/// Continuous voice-controlled navigation for the reels feed.
///
/// Listens in the background (once explicitly enabled by the user in
/// Settings) for the spoken words "up"/"back"/"previous" and
/// "down"/"next"/"skip", and fires the matching callback. This runs the
/// real on-device speech recognizer (`speech_to_text`, backed by Android's
/// SpeechRecognizer / iOS Speech framework) — it is not a stub.
///
/// Manual swipes are handled entirely separately by the feed's own
/// GestureDetector/PageView, so enabling voice control never blocks or
/// slows down fast manual swiping.
class VoiceControlService {
  final SpeechToText _speech = SpeechToText();
  bool _listening = false;

  static const _upWords = ['up', 'back', 'previous', 'ऊपर', 'पीछे'];
  static const _downWords = ['down', 'next', 'skip', 'नीचे', 'आगे'];

  Future<bool> start({
    required void Function() onUp,
    required void Function() onDown,
  }) async {
    if (_listening) return true;

    final available = await _speech.initialize();
    if (!available) return false;

    _listening = true;
    await _speech.listen(
      listenFor: const Duration(minutes: 30),
      pauseFor: const Duration(seconds: 5),
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: false,
        listenMode: ListenMode.confirmation,
      ),
      onResult: (result) {
        final text = result.recognizedWords.toLowerCase().trim();
        if (text.isEmpty) return;

        if (_upWords.any(text.contains)) {
          onUp();
        } else if (_downWords.any(text.contains)) {
          onDown();
        }

        // Re-arm listening after each phrase so it behaves like a
        // continuous command listener rather than a single-shot dialog.
        if (!_speech.isListening && _listening) {
          _speech.listen(
            listenFor: const Duration(minutes: 30),
            pauseFor: const Duration(seconds: 5),
            onResult: (r) {},
          );
        }
      },
    );
    return true;
  }

  Future<void> stop() async {
    _listening = false;
    if (_speech.isListening) {
      await _speech.stop();
    }
  }

  bool get isListening => _listening;
}
