import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceException implements Exception {
  final String message;
  VoiceException(this.message);

  @override
  String toString() => message;
}

/// Wraps the device's native speech recognition (STT) and native
/// text-to-speech (TTS) engines.
class VoiceService {
  VoiceService({this.sttLocaleId});

  /// e.g. 'en_US' or 'hi_IN'. Null = use the phone's default language.
  final String? sttLocaleId;

  final SpeechToText _stt = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _sttReady = false;
  bool _ttsReady = false;

  /// Called when the recogniser stops (silence, error, or manual stop).
  void Function()? onListeningStopped;

  /// Called with a readable message when recognition reports an error.
  void Function(String message)? onError;

  bool get isListening => _stt.isListening;

  // ------------------------------------------------------------------ STT

  Future<bool> _initSpeechRecognition() async {
    if (_sttReady) return true;
    try {
      _sttReady = await _stt.initialize(
        onStatus: (String status) {
          if (status == 'done' || status == 'notListening') {
            onListeningStopped?.call();
          }
        },
        onError: (dynamic e) {
          onError?.call(_friendlySttError(e.errorMsg as String));
          onListeningStopped?.call();
        },
      );
    } catch (_) {
      _sttReady = false;
    }
    return _sttReady;
  }

  /// Starts listening. [onText] receives the live transcript, and
  /// `isFinal == true` once the user has finished speaking.
  Future<void> startListening({
    required void Function(String words, bool isFinal) onText,
  }) async {
    final bool ok = await _initSpeechRecognition();
    if (!ok) {
      throw VoiceException(
          'Speech recognition is unavailable. Please allow microphone '
          'access and make sure a speech service (Google) is installed.');
    }
    await stopSpeaking();
    await _stt.listen(
      onResult: (SpeechRecognitionResult r) =>
          onText(r.recognizedWords, r.finalResult),
      localeId: sttLocaleId,
      listenFor: const Duration(seconds: 60),
      pauseFor: const Duration(seconds: 4),
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        listenMode: ListenMode.dictation,
      ),
    );
  }

  Future<void> stopListening() async {
    if (_stt.isListening) {
      await _stt.stop();
    }
  }

  String _friendlySttError(String code) {
    switch (code) {
      case 'error_permission':
        return 'Microphone permission is required for voice input.';
      case 'error_no_match':
      case 'error_speech_timeout':
        return "I didn't catch that. Please try again.";
      case 'error_network':
      case 'error_network_timeout':
        return 'Voice recognition needs an internet connection.';
      case 'error_busy':
        return 'Speech recognition is busy. Try again in a moment.';
      default:
        return 'Voice input error ($code).';
    }
  }

  // ------------------------------------------------------------------ TTS

  Future<void> _initTts() async {
    if (_ttsReady) return;
    await _tts.setSpeechRate(0.5);
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);
    _ttsReady = true;
  }

  /// Speaks [text] aloud. Markdown symbols are removed so the engine does not
  /// read out "asterisk" or "hash". Devanagari text is spoken with a Hindi
  /// voice, everything else with English.
  Future<void> speak(String text) async {
    String clean = _stripMarkdown(text);
    if (clean.isEmpty) return;
    // Android's TTS engine rejects input longer than ~4000 characters.
    if (clean.length > 3900) {
      final int cut = clean.lastIndexOf(' ', 3900);
      clean = clean.substring(0, cut > 0 ? cut : 3900);
    }
    try {
      await _initTts();
      await _tts.stop();
      await _tts.setLanguage(_languageFor(clean));
      await _tts.speak(clean);
    } catch (_) {
      // Speech output is optional; a TTS engine problem must never break chat.
    }
  }

  Future<void> stopSpeaking() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }

  String _languageFor(String text) =>
      RegExp(r'[\u0900-\u097F]').hasMatch(text) ? 'hi-IN' : 'en-US';

  String _stripMarkdown(String input) {
    String s = input;
    s = s.replaceAll(RegExp(r'```[\s\S]*?```'), ' ');
    s = s.replaceAllMapped(RegExp(r'\[([^\]]+)\]\([^)]+\)'), (Match m) => m[1]!);
    s = s.replaceAll(RegExp(r'https?://\S+'), ' ');
    s = s.replaceAll(RegExp(r'^\s{0,3}#{1,6}\s*', multiLine: true), '');
    s = s.replaceAll(RegExp(r'^\s*[-*+]\s+', multiLine: true), '');
    s = s.replaceAll(RegExp(r'[*_`~#>|]'), '');
    s = s.replaceAll(RegExp(r'\s+'), ' ');
    return s.trim();
  }

  Future<void> dispose() async {
    await stopListening();
    await stopSpeaking();
  }
}
